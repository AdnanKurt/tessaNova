/*This file has been prepared for Doxygen automatic documentation generation.*/
/*! \file *********************************************************************
*
* TESsaNova: tDCS TransCranial DC Brain Stimulator
* Developed for research studeies at MAKELab
*
* Adnan Kurt
* Teknofil
* 19Aug. 2013
* Zekeriyakoy, Istanbul
*
//  PP_Loop_Timer
//  Timer_B, Toggle P4.0-3, Cont. Mode ISR, DCO SMCLK
//
//  Use Timer_B CCRx units and overflow to generate four
//  independent timing intervals. not used: {For demonstration, CCR0, CCR1 and CCR2
//  output units are optionally selected with port pins P4.1, P4.2 and P4.3
//  in toggle mode}. As such, these pins will toggle when respective CCRx
//  registers match the TAR counter. Interrupts are also enabled with all
//  CCRx units, software loads offset to next interval only - as long as the
//  interval offset is added to CCRx, toggle rate is generated in hardware.
//  Timer_B overflow ISR is used to toggle P4.0 with software. Proper use of
//  the TBIV interrupt vector generator is demonstrated.
//  ACLK = n/a, MCLK = SMCLK = TACLK = default DCO ~800kHz 
//  AdKu Made DCO = 2000 kHz. AdKu ACLK = 4kHz  (32kHz/8)
//
//  As coded with TBCLK ~2000kHz DCO, toggle rates are:
//  P4.0= CCR0 = 2000kHz/(2*200)  ~5kHz		-Measured 4,88 kHz 	
//  P4.1= CCR1 = 2000kHz/(2*5000) ~200Hz	-Measured 195,3 Hz 	
//  P4.2= CCR2 = 2000kHz/(2*1000) ~1000Hz	-Measured 980,3 Hz   OK! AdKu
//  1 ms CCR2 pulsewidths
//  P4.6= overflow = 2000kHz/(2*65536) ~15Hz	 
//  -Measured 342 Hz (interfering with CitiWall Code) Measured 15Hz clean!
//
//               MSP430F149
//            -----------------
//        /|\|              XIN|-
//         | |                 |
//         --|RST          XOUT|-
//           |                 |
//           |         P4.0/Tb0|--> CCR0              pin 36
//           |         P4.1/Tb1|--> CCR1              pin 37
//           |         P4.2/Tb2|--> CCR2              pin 38
//           |             P4.6|--> Overflow/software pin 42
//  Adopted from:
//  M. Buccini
//  Texas Instruments Inc.
//  Feb 2005
//  
// This version of Loop Timer runs on TimerB. DAC_Write function relies on 
// TimerA interrupts, so this might be a better way to isolate the problems.
// Adnan Kurt
// Teknofil
// 12Feb.2012
// Etiler
//
// I've retouched the code and the comments.
// 10Sep2013
// AdKu
//
// Scaled with 2 for 4Mhz clock
//
*******************************************************************************/

//#include  <msp430x14x.h>
int main (void);
void heart_beat (void);
void HB_on (void);
void HB_off (void);
void EmergencyKey (void);
int EmergencyStopOld;
int EmergencyStopNew;
int Emergency;
unsigned int hr_count;
// unsigned int tick_count;

void HB_on 		(void){
  HeartBeat_LED  = 0;
}
void HB_off 		(void){
  HeartBeat_LED  = 1;
}

void Loop_Timer(void)
{
  					    // P4 o/p are good for debugging!
//  WDTCTL = WDTPW + WDTHOLD;               // Stop WDT
//  P4SEL |= 0x0F;                          // P4.0 - P4.3 option select
//  P4DIR |= 0xFF;                          // P4.0 - P4.7 outputs

  TBCCTL0 = OUTMOD_4 + CCIE;                // CCR0 toggle, interrupt enabled
  TBCCTL1 = OUTMOD_4 + CCIE;                // CCR1 toggle, interrupt enabled
  TBCCTL2 = OUTMOD_4 + CCIE;                // CCR2 toggle, interrupt enabled
  TBCTL = TBSSEL_2 +  MC_2 + TBIE;          // SMCLK, Contmode, int enabled

  EmergencyStopOld = 0;
  EmergencyStopNew = 0;
  heart_beat ();
}

// HeartBeat beats when Stimulation is OFF, during StandBy.
// When Stimulation_On is On, HB LED Turns On.
void heart_beat (void){
  if (Stimulation_On){
    HB_on ();
  } else{
	hr_count = (int)tick_count;
		if (((hr_count >> 10) & 0x01) == 1){
		HB_on ();
	} else { HB_off ();}
		if (((hr_count >> 8) & 0x01) == 1){
		HB_off ();
	}
  }
}

#pragma vector=TIMERB0_VECTOR
__interrupt void Timer_B0 (void)
{
  TBCCR0 += 400;                              // Add Offset to CCR0
}

#pragma vector=TIMERB1_VECTOR
__interrupt void Timer_B1 (void)
{
  switch( TBIV )
  {
//  P4.1= CCR1 = 4000kHz/(2*10000) ~200Hz   //
//  P4.2= CCR2 = 4000kHz/(2*4000) ~500Hz    // 1ms pulse widths
//  1 ms CCR2 pulsewidths
    
  case  2: TBCCR1 += 10000;                 // Add Offset to CCR1
        heart_beat ();
        break;
  case  4: TBCCR2 += 4000;                  // Add Offset to CCR2 1ms loop
	{
        bit.TickISR  = 1;                   // ISR handler used for timerB.   
        tick_count ++;                      // 1ms tick
//      P4OUT ^= 0x80;                      // counted signal -temporary on p4.7
// HeartBeat function adds big time jitter. Try using the function elsewhere.
//	heart_beat ();
	}
        break;
  case 14: 
//      P4OUT ^= 0x40;                      // Timer_B7 overflow on p4.6
        EmergencyKey();
        // Normally, Stimulation_trigger/ EmergencyKey input is at 0V.
	EmergencyStopNew = Emergency;	    // Test RunProcess button during loops
	if ((EmergencyStopOld & EmergencyStopNew) & !(Looping == 1))
        { 
            // TimerA would better be stopped. Otherwise conflicts might arise
            TACCTL0 &= ~CCIE;            // CCR0 interrupt disabled
            TACTL = TASSEL_2 + MC_0;     // SMCLK, Stop
            TACCR0 = 0;                  // Stop the TimerA
            // Additionally, OutPut Disable pin, OD might be pulled up.
            // Make sure that the Stimulator turns off.
            // set OD high
            XTR_Out_Disable = 0x01;
            // Sometimes unexpected freezing happens. Clear the looping as well
            Looping = 1;
	    main();			 // If pressed long enough and loop is 
	}			         // active then run Main 
	EmergencyStopOld = EmergencyStopNew;
        break;
 }
}

