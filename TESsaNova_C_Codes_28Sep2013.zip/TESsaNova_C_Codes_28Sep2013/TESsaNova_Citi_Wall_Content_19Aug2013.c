

/*This file has been prepared for Doxygen automatic documentation generation.*/
/*! \file *********************************************************************
 *
* TESsaNova: tDCS TransCranial DC Brain Stimulator
* Developed for research studeies at MAKELab
*
* User Interface, LCD Content File
*
* Adnan Kurt
* Teknofil
* 19Aug. 2013
* Zekeriyakoy, Istanbul
* - File:               TESsaNova_Board_Definition_File_19Aug2013.c
* - Compiler:           IAR EWBMSP430 5.40
* - Supported devices:  MSP430F149
* - Circuit:            TESsaNova_19Nov2011_F.sch
*
*  \author    AdKu            \n
*             Adnan Kurt      \n
*             Teknofil        \n
*             19Aug. 2013     \n
*             Zekeriyakoy, Istanbul
*
*
*******************************************************************************/

// LCD BoardSet 
// Welcome Screen
void Citi_Wall_0  (void)
{      
  initDisplay();
  printString("     tDCS       ");    // modulated transcranial dc stimulator
  gotoSecondLine();
  printString("    makeLAB     ");
  wait (1000);
  initDisplay();
  printString(" Teknofil  2013 ");
  gotoSecondLine();
  printString("   TESsaNova    ");  
  wait (1000);
}

void Citi_Wall_Params (void)        // Stimulation parameters display
  // initDisplay();
{                                   // 10*uA, 10*uA, 10*Hz, and s. 
  gotoFirstLine();                  // set values for AC stimulation current
  printString("acI dcI frQ dur ");  // DC stimulation current, AC frequency,
  gotoSecondLine();                 // stimulation duration; 
  // Displays AC current Amplitude in 10*uA
  printDecimal((int)Amplitude_Set_value/10);    
  printString(".");
  // Displays DC current Amplitude in 10*uA
  printDecimal((int)DC_Offset_Set_value/10);
  printString(".");
  // Displays Frequency in 10*Hz
  printDecimal((int)Frequency_Set_value);
  printString(".");
  // 10s to 3600s in Seconds, 10sec steps
  printDecimal((int)Stimulation_Duration/10);  
  printString("0");
}

void Citi_Wall_Params_DC (void)     // DC Stimulation parameters display
  // initDisplay();
{                                   // 10*uA, 10*uA, 10*Hz, and s. 
  gotoFirstLine();                  // set values for AC stimulation current
  printString("Current Duration");  // DC stimulation current, Duration,
  gotoSecondLine();                 // stimulation duration; 
  // Displays DC current Amplitude in 1*uA
  print4Decimal((int)DC_Offset_Set_value);
  printString("uA   ");
  // 10s to 3600s in Seconds, 10sec steps
  printDecimal((int)Stimulation_Duration/10);  
  printString("0sec");
}

// Following piece of code kept as a programming example.
/*
  if (Physical_FlowRate >= 10000)
  {
  printString("Flow in ul/sec  ");  // Speed (ul/ min), 
  gotoSecondLine();                 
  printDecimal((unsigned int)(Physical_FlowRate/1000));              
  printString(".");
  printString("0");
  printString(" ");
  printThreeDecimal((unsigned int)Volume_per_Step);
  printString("nlps");              // Gears (1 to 16), nanoliters per step 
//  printString(" Gear=");
//  printShortDecimal(Gear);
  }
  gotoFirstLine();  
  if ((Physical_FlowRate < 10000) && (Physical_FlowRate >= 10))
  {
  printString("Flow in nl/sec  ");  // Speed (nl/ sec), 
  gotoSecondLine();                 
  printDecimal((unsigned int)Physical_FlowRate);              
  printString(".");
  printString("0");
  printString(" ");
  printThreeDecimal((unsigned int)Volume_per_Step);
  printString("nlps");              // Gears (1 to 16), nanoliters per step 
//  printString(" Gear=");
//  printShortDecimal(Gear);
  }
}
*/

// Display during process
void Citi_Wall_Loops(void)
{            
  clearDisplay();
  gotoFirstLine();
//printString("acI dcI frQ dur ");        //use as a template
  printString("Stimulating ");
  gotoSecondLine();
  printString(">  > >>> ");
  printDecimal((int)Stimulation_Duration/10 );   // 10s to 3600s S c a l e to display
  printString("0 s");
}

// Display during self testing
void Citi_Wall_Testing(void)
{            
  clearDisplay();
  gotoFirstLine();
//printString("acI dcI frQ dur ");        //use as a template
  printString("TESsaNova  tDCS ");
  gotoSecondLine();
  printString("self testing... ");
}

// Display during clock-set
void Clock_Setting (void)
{             
  initDisplay();
  gotoFirstLine();
  printString("Clock Tuning");
  gotoSecondLine();
  printString("oooooooooooo");
}

// Display after saving
void Parameters_Saved (void)
{             
  initDisplay();
  gotoFirstLine();
  printString("Parameters  ");
  gotoSecondLine();
  printString("Memorized.  ");
}

// Display after Stimulation End
void CitiWall_FinalReport (void)
{             
  clearDisplay();
  gotoFirstLine();
  printString("Stimulation Done");
  gotoSecondLine();
  printString("<io> = ");
  printDecimal((int)Last_RMS_Current);  
  printString(" mA");
  printString("duration= ");
  printDecimal((int)Duration / 10);    // 100ms to 100s S c a l e to display
  printString("0");
  printString("mS");
}

void Citi_Wall_Battery (void)
{         
  clearDisplay();
  gotoFirstLine();
//printString("acI dcI frQ dur ");        //use as a template  
  printString("Vbattery=");
  printDecimal((int)Vs_Read_value);       // 1.0 to 18.0 V to display
  gotoSecondLine();
  printString("Change Battery! ");
}

void Citi_Wall_Overcurrent_Warning (void)
{
  clearDisplay();
  gotoFirstLine();
//printString("acI dcI frQ dur ");        //use as a template  
  printString("acI+dcI > 4000uA");
  gotoSecondLine();
  printString("Revise Values!  ");
} 
/*
// Error display: get data from error_list()
void Citi_Wall_Err (void)
{         
  clearDisplay();
  gotoFirstLine();
  printString("Error Report: ");
  gotoSecondLine();
  error_list(set_fault);
  printString(error_is);
}
*/