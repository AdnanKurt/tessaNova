
/*This file has been prepared for Doxygen automatic documentation generation.*/
/*! \file *********************************************************************
 *
* TESsaNova: tDCS TransCranial DC Brain Stimulator
* Developed for research studies at MAKELab
*
* DAC Drive & Wave Generation File
*
* Adnan Kurt
* Teknofil
* 12Sep. 2013
* Zekeriyakoy, Istanbul
* - File:               TESsaNova_DAC_Drive19Aug2013.c
* - Compiler:           IAR EWBMSP430 5.40
* - Supported devices:  MSP430F149
* - Circuit:            TESsaNova_19Nov2011_F.sch
*
*  \author    AdKu            \n
*             Adnan Kurt      \n
*             Teknofil        \n
*             12Sep. 2013     \n
*             Zekeriyakoy, Istanbul
*
//
//  Description: Drive the DAC8551 through SPI to Generate CuCu -
//  Currunt Control Signal
//  DAC output to be 0-5Vdc, and AD8603 opamp will scale it down
//  to 0-2Vdc. IC801 output to be fed intoIC501B OPA2336B, which
//  forms the current sink loop. It generates 0-200mA with 0-2V input.
//
//  SPI connection to DAC8551:
//
//            MSP430F149
//            -----------------
//        /|\|              XIN|-
//         | |                 |           DAC8551
//         --|RST          XOUT|-       -------------
//           |             P3.0|------>|FS        OUT|--> ~ 390Hz
//           |       SIMO0/P3.1|------>|DIN          |
//           |       UCLK0/P3.3|------>|SCLK       CS|-|
//           |                 |       |             | v
//
//
//
//
//
//  A.Kurt
//  Teknofil
//  29Oct.2012
//
//  Description: USART0 in SPI mode interface to DAC8551 DAC.
//  USART0 is used to transmit data to DAC, software generated frame sync
//  pulse, DAC is updated inside CCR0 ISR operating in continuos mode.
//  ACLK= n/a, MCLK= SMCLK= UCLK= default DCOCLK
//  
//
//  Power on Reset to Zero O/P!
//  O/P Voltage: 0 to Vref
//  10uS settling time
//  Vout = (Din/65536)*Vref :Din -decimal equivalent of binary code
//  ADR444 used as a reference. 4096mV 
//  DCO set to 4Mhz in Clock_Set()  
// 
//  Adnan Kurt 
//  Teknofil
//  Zekeriyakoy
//  30Oct2012
// To be done:
// Generate Exponential, Linear and constant Waves. Select whichever 
// required with the calling function.
// Wave to be generated with the given parameters. May be it would be
// better to create the wave first, and then call the DAC_Write routine
// So, first call CurrentWave_SetUp (Output_Current_Set), then DAC_Write()
//
// Some reference codes, left orphan during SW development. I keep those
// here for future reference.
//
// Adnan Kurt
// 19Dec2012
//
// LED measurements spend very small current, so I2m keeping them active now. 
// Later, could be used for other purposes anyway.
// Adnan Kurt
// 17Sep2013
//
*******************************************************************************/

/*
//Good for standalone DAC output
void DAC_Write(int Wave_tab[])
{
  P3OUT |= 0x1;                             // FS set
  P3OUT &= ~0x1;                            // FS reset
  TXBUF0 = 0x00;
    while(!(U0TCTL & 0x01))
    {
    }
  TXBUF0 = Wave_tab[pointer] >> 8;          // Hi Byte
    while(!(U0TCTL & 0x01))
    {
    }  
  TXBUF0 = Wave_tab[pointer];               // Lo Byte
    while(!(U0TCTL & 0x01))
    {  
    }  
  pointer++;
    if (pointer >= Wave_Size)
    {
    pointer = 0;                            // Will not repeat. So change it!
    }
}
*/

/*
Another reference, with subsampling
// Timer A0 interrupt service routine
#pragma vector=TIMERA0_VECTOR
__interrupt void Timer_A0(void)
{
  P3OUT |= 0x1;                             // FS set
  P3OUT &= ~0x1;                            // FS reset

  TXBUF0 = 0x00;
  while(!(U0TCTL & 0x01)){
  }
//  output = Sin_tab[pointer]*amplitude/5.25;
  output = Sin_tab[pointer];
  TXBUF0 = output >> 8;
  while(!(U0TCTL & 0x01)){
  }  
  TXBUF0 = output;
  while(!(U0TCTL & 0x01)){
  } 
  
     P3OUT |= 0x1;                            // FS set
     pointer++;
     pointer++;
//   pointer++;     // Sub Sample
//   pointer++;     // With 4 ++, maximum frequency of sin wave is 436Hz.
     pointer &= 0xFF;
}
*/
// *************************************************************************
 /*
  This switch selection is good for arbitary wave generation
  however, memory management problems might arise. Instead, preset 
  Wave tables will be used.
    switch (fMode)
    {
    case "DC" : 
      for (Time_Step = 0; Time_Step <= on_Time; Time_Step++)
      {
      Wave_tab [Time_Step] = (int) Output_Current_Set * 0xFFFF / 4.096;  
      //  Wave_tab [Time_Step] = 1;
      };
    break;
    case "Exponential" :
      for (Time_Step = 0; Time_Step <= on_Time; Time_Step++)
      {
      Wave_tab [Time_Step] = (int) Output_Current_Set * 0xFFFF / 4.096;  
      //  Wave_tab [Time_Step] = 1;
      };
    break;
    case "Linear" : 
      for (Time_Step = 0; Time_Step <= on_Time; Time_Step++)
      {
      Wave_tab [Time_Step] = (int) Output_Current_Set * 0xFFFF / 4.096;  
      //  Wave_tab [Time_Step] = 1;
      };
    break;
    case "Sine" :
      for (Time_Step = 0; Time_Step <= on_Time; Time_Step++)
      {
      Wave_tab [Time_Step] = (int) Output_Current_Set * 0xFFFF / 4.096;  
      //  Wave_tab [Time_Step] = 1;
      };
    break;
    default: 
      for (Time_Step = 0; Time_Step <= on_Time; Time_Step++)
      {
      Wave_tab [Time_Step] = (int) Output_Current_Set * 0xFFFF / 4.096;  
      //  Wave_tab [Time_Step] = 1;
      };
    break;
    }
  */
// 
// *************************************************************************
//
/* Peripherals Used
# define  &SYNC                   P3OUT_bit.P3OUT_0   // SPI Sync
# define  DIN                     P3OUT_bit.P3OUT_1   // DAC Data SPI
# define  SCLK                    P3OUT_bit.P3OUT_3   // SPI Clock
*/

/* Function Prototypes 
void CurrentWave_SetUp ()             // Vout generated 0-5Vdc
// Wave to be generated with the given parameters. May be it would be
// better to create the wave first, and then call the DAC_Write routine
void DAC_Write(io_set)
// So, first call Current_Set(), then DAC_Write()
*/
//
//
//******************************************************************************

// variable declarations 
// int Time_Step = 0;
// int on_Time = 100;
int Wave_Size = 500;
int Wave_tab [100] = {0};
int sample_Wave_tab = 0;
unsigned int Time_Step;                     // 16-bit value to write
// experimental data
// Io= DAC#/12240 mA
// DAC# = Sin_Wave_Tab[step] * (12240/0xFFFF) * Io_set_Value mA)
// DAC# = (Sin_Wave_Tab[step] / 5354)* Io_set_Value (uA)
// DAC# = (Sin_Wave_Tab[step] / 54)* Io_set_Value (mA)*10
// DAC# = (Sin_Wave_Tab[step] / 27)* Io_set_Value (mA)*5
// This should be better:
// DAC# = (Sin_Wave_Tab[step] / 54)* Io_set_Value (mA)*10
// Scaled Amplitude is served in uA, up to 2000uA
unsigned int DAC_Scale = 54;                    
unsigned int io_set;
unsigned int scaled_AC_Amplitude;
unsigned int scaled_DC_Amplitude;
// Smoother is the scaling variable for output ramping
unsigned int Smoother = 0;
int Let_Wave_Out;
int SubSamples = 4;

// Sinusoidal wave generated for 500 samples, max value is 0xFFFF
// corresponding to 0-2PI period, with a single sine wave
// Subsampling might require more data, so added 40 more
const unsigned int Sin_Wave_tab[541] = {
33179,33590,34002,34413,34824,35235,35646,36056,36465,36874,
37282,37690,38096,38502,38907,39311,39714,40116,40516,40916,
41314,41711,42106,42500,42893,43284,43673,44060,44446,44830,
45211,45591,45969,46345,46719,47090,47459,47826,48191,48553,
48912,49269,49624,49976,50325,50671,51014,51355,51693,52027,
52359,52687,53013,53335,53654,53969,54282,54591,54896,55198,
55496,55791,56082,56370,56653,56933,57210,57482,57750,58015,
58275,58532,58784,59032,59276,59516,59752,59984,60211,60434,
60652,60866,61076,61281,61481,61677,61869,62056,62238,62416,
62589,62757,62921,63079,63233,63383,63527,63666,63801,63931,
64056,64175,64290,64400,64505,64605,64700,64790,64874,64954,
65029,65098,65163,65222,65276,65325,65369,65408,65441,65470,
65493,65511,65524,65532,65535,65532,65524,65511,65493,65470,
65441,65408,65369,65325,65276,65222,65163,65098,65029,64954,
64874,64790,64700,64605,64505,64400,64290,64175,64056,63931,
63801,63666,63527,63383,63233,63079,62921,62757,62589,62416,
62238,62056,61869,61677,61481,61281,61076,60866,60652,60434,
60211,59984,59752,59516,59276,59032,58784,58532,58275,58015,
57750,57482,57210,56933,56653,56370,56082,55791,55496,55198,
54896,54591,54282,53969,53654,53335,53013,52687,52359,52027,
51693,51355,51014,50671,50325,49976,49624,49269,48912,48553,
48191,47826,47459,47090,46719,46345,45969,45591,45211,44830,
44446,44060,43673,43284,42893,42500,42106,41711,41314,40916,
40516,40116,39714,39311,38907,38502,38096,37690,37282,36874,
36465,36056,35646,35235,34824,34413,34002,33590,33179,32767,
32355,31944,31532,31121,30710,30299,29888,29478,29069,28660,
28252,27844,27438,27032,26627,26223,25820,25418,25018,24618,
24220,23823,23428,23034,22641,22250,21861,21474,21088,20704,
20323,19943,19565,19189,18815,18444,18075,17708,17343,16981,
16622,16265,15910,15558,15209,14863,14520,14179,13841,13507,
13175,12847,12521,12199,11880,11565,11252,10943,10638,10336,
10038,9743,9452,9164,8881,8601,8324,8052,7784,7519,7259,7002,
6750,6502,6258,6018,5782,5550,5323,5100,4882,4668,4458,4253,
4053,3857,3665,3478,3296,3118,2945,2777,2613,2455,2301,2151,
2007,1868,1733,1603,1478,1359,1244,1134,1029,929,834,744,660,
580,505,436,371,312,258,209,165,126,93,64,41,23,10,2,0,2,10,
23,41,64,93,126,165,209,258,312,371,436,505,580,660,744,834,
929,1029,1134,1244,1359,1478,1603,1733,1868,2007,2151,2301,
2455,2613,2777,2945,3118,3296,3478,3665,3857,4053,4253,4458,
4668,4882,5100,5323,5550,5782,6018,6258,6502,6750,7002,7259,
7519,7784,8052,8324,8601,8881,9164,9452,9743,10038,10336,10638,
10943,11252,11565,11880,12199,12521,12847,13175,13507,13841,
14179,14520,14863,15209,15558,15910,16265,16622,16981,17343,
17708,18075,18444,18815,19189,19565,19943,20323,20704,21088,
21474,21861,22250,22641,23034,23428,23823,24220,24618,25018,
25418,25820,26223,26627,27032,27438,27844,28252,28660,29069,
29478,29888,30299,30710,31121,31532,31944,32355,32767,33179,
33179,33590,34002,34413,34824,35235,35646,36056,36465,36874,
37282,37690,38096,38502,38907,39311,39714,40116,40516,40916,
41314,41711,42106,42500,42893,43284,43673,44060,44446,44830,
45211,45591,45969,46345,46719,47090,47459,47826,48191,48553,
};

// Sigmoid wave generated for 101 samples, max value is 1000dec
const unsigned int Sigmoid_Wave_tab[103] = {
1, 15, 16, 17, 18, 19, 20, 21, 22, 24, 25, 27, 29, 31, 33, 35, 38, 
41, 44, 48, 52, 57, 62, 69, 76, 83, 93, 103, 115, 130, 146, 165, 
187, 213, 242, 276, 314, 356, 401, 450, 500, 549, 598, 643, 685, 
723, 757, 786, 812, 834, 853, 869, 884, 896, 906, 916, 923, 930, 
937, 942, 947, 951, 955, 958, 961, 964, 966, 968, 970, 972, 974, 
975, 977, 978, 979, 980, 981, 982, 983, 984, 985, 985, 986, 987, 
987, 988, 988, 989, 989, 989, 990, 990, 991, 991, 991, 991, 992, 
992, 992, 992, 993, 993, 1000,
};

// Ramp wave generated for 500 samples, max value is 0xFFFF
const unsigned int Ramp_Wave_tab[501] = {
0,131,262,393,524,655,786,917,1048,1179,1310,1441,1572,1703,
1834,1966,2097,2228,2359,2490,2621,2752,2883,3014,3145,3276,
3407,3538,3669,3801,3932,4063,4194,4325,4456,4587,4718,4849,
4980,5111,5242,5373,5504,5636,5767,5898,6029,6160,6291,6422,
6553,6684,6815,6946,7077,7208,7339,7470,7602,7733,7864,7995,
8126,8257,8388,8519,8650,8781,8912,9043,9174,9305,9437,9568,
9699,9830,9961,10092,10223,10354,10485,10616,10747,10878,11009,
11140,11272,11403,11534,11665,11796,11927,12058,12189,12320,
12451,12582,12713,12844,12975,13107,13238,13369,13500,13631,
13762,13893,14024,14155,14286,14417,14548,14679,14810,14941,
15073,15204,15335,15466,15597,15728,15859,15990,16121,16252,
16383,16514,16645,16776,16908,17039,17170,17301,17432,17563,
17694,17825,17956,18087,18218,18349,18480,18611,18743,18874,
19005,19136,19267,19398,19529,19660,19791,19922,20053,20184,
20315,20446,20577,20709,20840,20971,21102,21233,21364,21495,
21626,21757,21888,22019,22150,22281,22412,22544,22675,22806,
22937,23068,23199,23330,23461,23592,23723,23854,23985,24116,
24247,24379,24510,24641,24772,24903,25034,25165,25296,25427,
25558,25689,25820,25951,26082,26214,26345,26476,26607,26738,
26869,27000,27131,27262,27393,27524,27655,27786,27917,28048,
28180,28311,28442,28573,28704,28835,28966,29097,29228,29359,
29490,29621,29752,29883,30015,30146,30277,30408,30539,30670,
30801,30932,31063,31194,31325,31456,31587,31718,31850,31981,
32112,32243,32374,32505,32636,32767,32898,33029,33160,33291,
33422,33553,33684,33816,33947,34078,34209,34340,34471,34602,
34733,34864,34995,35126,35257,35388,35519,35651,35782,35913,
36044,36175,36306,36437,36568,36699,36830,36961,37092,37223,
37354,37486,37617,37748,37879,38010,38141,38272,38403,38534,
38665,38796,38927,39058,39189,39321,39452,39583,39714,39845,
39976,40107,40238,40369,40500,40631,40762,40893,41024,41155,
41287,41418,41549,41680,41811,41942,42073,42204,42335,42466,
42597,42728,42859,42990,43122,43253,43384,43515,43646,43777,
43908,44039,44170,44301,44432,44563,44694,44825,44957,45088,
5219,45350,45481,45612,45743,45874,46005,46136,46267,46398,
46529,46660,46791,46923,47054,47185,47316,47447,47578,47709,
47840,47971,48102,48233,48364,48495,48626,48758,48889,49020,
49151,49282,49413,49544,49675,49806,49937,50068,50199,50330,
50461,50593,50724,50855,50986,51117,51248,51379,51510,51641,
51772,51903,52034,52165,52296,52428,52559,52690,52821,52952,
53083,53214,53345,53476,53607,53738,53869,54000,54131,54262,
54394,54525,54656,54787,54918,55049,55180,55311,55442,55573,
55704,55835,55966,56097,56229,56360,56491,56622,56753,56884,
57015,57146,57277,57408,57539,57670,57801,57932,58064,58195,
58326,58457,58588,58719,58850,58981,59112,59243,59374,59505,
59636,59767,59898,60030,60161,60292,60423,60554,60685,60816,
60947,61078,61209,61340,61471,61602,61733,61865,61996,62127,
62258,62389,62520,62651,62782,62913,63044,63175,63306,63437,
63568,63700,63831,63962,64093,64224,64355,64486,64617,64748,
64879,65010,65141,65272,65403,65535,
};

// Generate a wave, to output at DAC
// Time base should be TimerA generated PP_Loop_Timer signal
// to synchronize with rest of the program.
// Vout generated 0-5Vdc
void CurrentWave_SetUp (void) 
{
  P3SEL |= 0xA;                             // P3.1,3 SPI option select
  P3DIR |= 0xB;                             // P3.0,1,3 output direction
  P3OUT &= ~0x01;                            // FS reset
  ME1 |= USPIE0;                            // Enable USART0 SPI
  UCTL0 |= CHAR + SYNC + MM;                // 8-bit SPI Master **SWRST**
  UTCTL0 = CKPH + CKPL + SSEL1+SSEL0+STC;   // Inv. delayed, SMCLK, 3-pin
  UBR00 = 0x02;                             // SMCLK/2 for baud rate AK.
  UBR10 = 0x0;                              // SMCLK/2 for baud rate AK.
  UMCTL0 = 0x0;                             // Clear modulation
  UCTL0 &= ~SWRST;                          // Initialize USART state machine
  Time_Step = 0;                            // Clear pointer
// SMCLK = 4Mhz and step size to be determined with PP_Loop_Timer at DAC output.
}

// DAC_Write(io_set) function receives a 16bit current value, from the main loop
// and send the data to DAC. It does not take care of timing. However, pointer
// addressing the value in the Wave_tab[] is incremented and reset if required.
/*
    case "DC" : 1
    case "Exponential" : 2
    case "Linear" : 3
    case "Sine" : 4
*/
void DAC_Write(int fMode, int Time_Step, int scaledAmplitude, int scaled_Offset)
{
  // Timing could be observed over LED p5_7 as:
  // LED901 or R901
  //  ___|WaveCalculations|_|SPI communications|__
  // In order to measure loop period, Turn on p5_7 Board LED
  p5_7 = 1;
  // This section took 100uS to process case2
  // This section took  56uS to process case1
  switch (fMode)
    {
    case 1 : 
      // DAC# = (Sin_Wave_Tab[step] / 54)* Io_set_Value (mA)*10
      // SuperPosed = DAC# + DC_Offset_Value
      io_set = scaledAmplitude * (Sin_Wave_tab [Time_Step] / DAC_Scale);
      io_set = io_set + scaled_Offset;
    break;
    case 2 :
      // DAC# = (Sin_Wave_Tab[step] / 54)* Io_set_Value (mA)*10
      // SuperPosed = DAC# + DC_Offset_Value
      io_set = scaledAmplitude * (Sin_Wave_tab [Time_Step] / DAC_Scale);
      io_set = io_set + scaled_Offset;
      io_set = (io_set/100)*Smoother;
    break;
    case 3 : 
      // This is to generate constant DC current output
      io_set = scaled_Offset;
    break;
    case 4 :
      // DAC# = (Sin_Wave_Tab[step] / 54)* Io_set_Value (mA)*10
      io_set = scaledAmplitude * (Sin_Wave_tab [Time_Step] / DAC_Scale);
    break;
    case 5 :
      // To set output to Zero!
      io_set = 0x00;
    break;
    default: 
      // To set output to Zero!
      io_set = 0x00;
    break;
    }
  // Setting the clock to 4MHz, achieved 18Hz in Mode4. TAU=400, minimum value.
  // Took 11-12 uS to calculate in Mode2, TAU set to 400, f to 10 Hz.
  // Took 11.2 uS to calculate in Mode2. TAU set t0 4000 & 20000.
  // Took 29 uS to calculate in Mode2.  TAU set t0 40. Limiting with ISR
  // Took 175 uS to calculate in Mode2.  TAU set t0 20. Limiting with ISR
  // Took 100 uS to calculate in Mode4, TAU set to 400, f to 10 Hz.
  // Took 90 uS to calculate in Mode4. TAU set t0 4000 & 20000.
  // Took 241 uS to calculate in Mode4.  TAU set t0 40. Limiting with ISR
  // Took 1900 uS to calculate in Mode4.  TAU set t0 20. Limiting with ISR
  // In order to measure Calculation loop period, Turn off p5_7 Board LED
  p5_7 = 0;
  // Took 1.6uS
  __no_operation();
  p5_7 = 1;
  P3OUT |= 0x01;                             // FS set
  P3OUT &= ~0x01;                            // FS reset
  TXBUF0 = 0x00;
    while(!(U0TCTL & 0x01))
    {
    }
  TXBUF0 = io_set >> 8;              // Hi Byte
    while(!(U0TCTL & 0x01))
    {
    }  
  TXBUF0 = io_set;                   // Lo Byte
    while(!(U0TCTL & 0x01))
    {  
    }
    // Well, whatever the frequency set value is, when CCIE is set,
    // ie., ISR served, it takes longer time. When CCIE is 0,
    // It takes about 12uS to do the calculation! It took 120uS with 
    // frequency set to 190 Hz. Yes, ISR takes rime and makes timing chaotic.
    // Took 110 uS to calculate in Mode2, TAU set to 400, f to 10 Hz.
    // Took 95uS to calculate in Mode2. TAU set t0 4000 & 20000.
    // Took 200 uS to calculate in Mode2.  TAU set t0 40. Limiting with ISR
    // Took 920 uS to calculate in Mode2.  TAU set t0 20. Limiting with ISR
    // Took 189 uS to calculate in Mode4, TAU set to 400, f to 10 Hz.
    // Took 220 uS to calculate in Mode4. TAU set t0 4000 & 20000.
    // Took 365 uS to calculate in Mode4.  TAU set t0 40. Limiting with ISR
    // Took 2800 uS to calculate in Mode4.  TAU set t0 20. Limiting with ISR
    // Took 100 uS for transmission. -somewhere in between.
    // In order to measure loop period, Turn off p5_7 Board LED
    // Took 30 uS to process from   __no_operation(); mode2
    // Took 30 uS to process from   __no_operation(); mode1
    p5_7 = 0;
}

void Init_Output_Timing(int TAU)
{
  TACCTL0 = CCIE;                           // CCR0 interrupt enabled
//  TACCR0 = 64-1;                          // ~ 390Hz Clock period
//  Default DCO 800kHz, and with 32 samples, fDAC is 390Hz
  TACCR0 = TAU-1;
  TACTL = TASSEL_2 + MC_1;                  // SMCLK, Up-mode
}

void Halt_Output_Timing(void)
{
  TACCTL0 &= ~CCIE;                         // CCR0 interrupt disabled
  TACCR0 = 0;                               // Reset Clock period
  TACTL = TASSEL_2 + MC_0;                  // SMCLK, Stop
}

// This function is used for testing on human model measurements
// and device testing
// CuSa -output current will be measured and averaged
void Test_Stimulation_Output(int AC_Amplitude, int DC_Amplitude, int Frequency, int Duration)
{
  // fMode is 3, DC constant current output
   CurrentWave_SetUp();
  // DAC# = (Sin_Wave_Tab[step] / 54)* Io_set_Value (mA/10)
  // io_set = scaledAmplitude * (Sin_Wave_tab [Time_Step] / DAC_Scale);
  // void DAC_Write(int fMode, int Time_Step, int Amplitude)
  // scaled_AC_Amplitude = (AC_Amplitude * 10)/1000;
   scaled_AC_Amplitude = AC_Amplitude/100;
  // DC offset value will be calculated and added to the tabulated
  // waveform data. A self correction algorithm might be implemented.
  // Minimum and maximum values cause confusion. So that might be
  // handled automatically.
   scaled_DC_Amplitude = (DC_Amplitude/100)*(0xFFFF/DAC_Scale);
  SubSamples = 4;
  int TAU = (80000/ Frequency)*SubSamples ;
  Let_Wave_Out = 0;
  bit.TickISR = 0;
  unsigned int Session_Counter = 0;
  unsigned int Session_Length = 0;
  unsigned int Step = 0;
  Init_Output_Timing(TAU);
  while (Session_Length < Duration)
  {
    if (bit.TickISR)
    { 
      Session_Counter ++;
      // Counts Session length in seconds. Seconds counted with 
      // ms pulses from TimerB ISR
      if (Session_Counter >= 100)
      {
        Session_Counter = 0;
        Session_Length ++;
      }
      bit.TickISR = 0;
    }
    if (Let_Wave_Out)
    {
      Step = Step + SubSamples;
      Let_Wave_Out = 0;
      // Error Beacon will light when there is a current drive error.
      Error_Beacon = XTR_Error;
      // Mode1 is required for non-corrected waveform generation.
      DAC_Write(1, Step, scaled_AC_Amplitude, scaled_DC_Amplitude);
      // Read Current Samples
      Sense_Current();
      if ((fabs (DC_Amplitude - Sense_i_value)) > (DC_Amplitude/10))
      {
        // Error Beacon will light when there is a current drive error.
        // Error expected to be less than 10%
        Error_Beacon_on();
      }
      else
      {
        Error_Beacon_off();
      }
      if (Step >= 500)
      {
        Step = 0;
      }
    }
  }
    // Graceful Ending
    // Set Output to Zero!
    // Resulted in 24mV output. Acceptable.
      Error_Beacon_off ();
      DAC_Write(5, Step, scaled_AC_Amplitude, scaled_DC_Amplitude);
Halt_Output_Timing();
}

// This function is required for short stimulations
// or whenever ramp needs to be eliminated.
void Rampless_Stimulate(int AC_Amplitude, int DC_Amplitude, int Frequency, int Duration)
{
  // fMode is 4, Sin output
  // DCO is 4Mhz, so 500 points Wave period is (4000k/TAU)/500 Hz
  // TAU = 4000000/(ACfreq*500)
  // int TAU = (80000/ Frequency)*SubSamples;
   CurrentWave_SetUp();
  // DAC# = (Sin_Wave_Tab[step] / 54)* Io_set_Value (mA/10)
  // io_set = scaledAmplitude * (Sin_Wave_tab [Time_Step] / DAC_Scale);
  // void DAC_Write(int fMode, int Time_Step, int Amplitude)
  // scaled_AC_Amplitude = (AC_Amplitude * 10)/1000;
   scaled_AC_Amplitude = AC_Amplitude/100;
  // DC offset value will be calculated and added to the tabulated
  // waveform data. A self correction algorithm might be implemented.
  // Minimum and maximum values cause confusion. So that might be
  // handled automatically.
   scaled_DC_Amplitude = (DC_Amplitude/100)*(0xFFFF/DAC_Scale);
  // Sampling to be redefined, in order to get better resolution 
  // at lower frequencies
  // frequency unit will be dHz!
  // So, different subsampling definitions need to be done:
  if (Frequency >0 && Frequency <= 10)
  {
    SubSamples = 1;
  }
    if (Frequency >0 && Frequency <= 100)
  {
    SubSamples = 1;
  }
    if (Frequency >100 && Frequency <= 200)
  {
    SubSamples = 2;
  }
    if (Frequency >200 && Frequency <= 300)
  {
    SubSamples = 3;
  }
    if (Frequency >300 && Frequency <= 500)
  {
    SubSamples = 4;
  }
    if (Frequency >500 && Frequency <= 600)
  {
    SubSamples = 5;
  }
    if (Frequency >600 && Frequency <= 800)
  {
    SubSamples = 6;
  }
    if (Frequency >800 && Frequency <= 1000)
  {
    SubSamples = 7;
  }
    if (Frequency > 1000)
  {
    SubSamples = 8;
  }
  // Frequency accuracy is about 1%. Think about it.
  // minimum frequency that will be delivered from Pot is 0.1Hz, 1dHz.
  // maximum frequency to get is 80Hz, or 800dHz.
  // frequency unit will be dHz!
  // Minimum TAU was found to be 400, including all the overhead.
  // So, an offset will help to get required frequency.
  // In order to get frequencies lower than 10 dHz, oversampling required.
  int TAU = (80000/ Frequency)*SubSamples ;
  Let_Wave_Out = 0;
  bit.TickISR = 0;
  unsigned int Session_Counter = 0;
  // Calculate Smoother number for Sigmoid_Length of time
  unsigned int Session_Length = 0;
  unsigned int Step = 0;
  Init_Output_Timing(TAU);
  // There happen to be a current peaking, maybe just from relay switching.
  // Trying to eliminate it:
  DAC_Write(1, 1, 10, 10);
  while (Session_Length < Duration)
  {
    if (bit.TickISR)
    { 
      Session_Counter ++;
      // Counts Session length in seconds. Seconds counted with 
      // ms pulses from TimerB ISR
      if (Session_Counter >= 1000)
      {
        Session_Counter = 0;
        Session_Length ++;
      }
      bit.TickISR = 0;
    }
    if (Let_Wave_Out)
    {
      Step = Step + SubSamples;
      Let_Wave_Out = 0;
      // Error Beacon will light when there is a current drive error.
      Error_Beacon = XTR_Error;
      // Mode1 is required for non-corrected waveform generation.
      // DAC_Write(1, Step, scaled_AC_Amplitude, scaled_DC_Amplitude);
      // Mode1 is used for non-corrected waveform generation.
      // scaled_AC_Amplitude = 0
      DAC_Write(1, Step, 0, scaled_DC_Amplitude);
      if (Step >= 500)
      {
        Step = 0;
      }
    }
  }
    // Graceful Ending
    // Set Output to Zero!
    // Resulted in 24mV output. Acceptable.
      Error_Beacon_off ();
      DAC_Write(5, Step, scaled_AC_Amplitude, scaled_DC_Amplitude);
Halt_Output_Timing();
}

void Stimulation_Output (int AC_Amplitude, int DC_Amplitude, int Frequency, int Duration)
{
// fMode is 4, Sin output
// DCO is 4Mhz, so 500 points Wave period is (4000k/TAU)/500 Hz
// TAU = 4000000/(ACfreq*500)
// int TAU = (80000/ Frequency)*SubSamples;
   CurrentWave_SetUp();
  // DAC# = (Sin_Wave_Tab[step] / 54)* Io_set_Value (mA/10)
  // io_set = scaledAmplitude * (Sin_Wave_tab [Time_Step] / DAC_Scale);
  // void DAC_Write(int fMode, int Time_Step, int Amplitude)
  // scaled_AC_Amplitude = (AC_Amplitude * 10)/1000;
   scaled_AC_Amplitude = AC_Amplitude/100;
   // DC offset value will be calculated and added to the tabulated
   // waveform data. A self correction algorithm might be implemented.
   // Minimum and maximum values cause confusion. So that might be
   // handled automatically.
   scaled_DC_Amplitude = (DC_Amplitude/100)*(0xFFFF/DAC_Scale);
  // Sampling to be redefined, in order to get better resolution 
  // at lower frequencies
  // frequency unit will be dHz!
  // So, different subsampling definitions need to be done:
  if (Frequency >0 && Frequency <= 10)
  {
    SubSamples = 1;
  }
    if (Frequency >0 && Frequency <= 100)
  {
    SubSamples = 1;
  }
    if (Frequency >100 && Frequency <= 200)
  {
    SubSamples = 2;
  }
    if (Frequency >200 && Frequency <= 300)
  {
    SubSamples = 3;
  }
    if (Frequency >300 && Frequency <= 500)
  {
    SubSamples = 4;
  }
    if (Frequency >500 && Frequency <= 600)
  {
    SubSamples = 5;
  }
    if (Frequency >600 && Frequency <= 800)
  {
    SubSamples = 6;
  }
    if (Frequency >800 && Frequency <= 1000)
  {
    SubSamples = 7;
  }
    if (Frequency > 1000)
  {
    SubSamples = 8;
  }
  // Frequency accuracy is about 1%. Think about it.
  // minimum frequency that will be delivered from Pot is 0.1Hz, 1dHz.
  // maximum frequency to get is 80Hz, or 800dHz.
  // frequency unit will be dHz!
  // Minimum TAU was found to be 400, including all the overhead.
  // So, an offset will help to get required frequency.
  // In order to get frequencies lower than 10 dHz, oversampling required.
  int TAU = (80000/ Frequency)*SubSamples ;
  Let_Wave_Out = 0;
  bit.TickISR = 0;
  unsigned int Session_Counter = 0;
  // Calculate Smoother number for Sigmoid_Length of time
  unsigned int Session_Length = 0;
  // Sigmoid_Multiple is the variable that holds scaling period.
  // It is taken to be 150mS
  unsigned int Sigmoid_Multiple = 150;
  // Ramp_Count is used to track ramping period counts.
  // It will count to 100 (103 indeed) to get 15sec ramp
  unsigned int Ramp_Count = 0;
  // Sigmoid_Counter is used to store total ramping duration
  unsigned int Sigmoid_Counter = 0;
  unsigned int Sigmoid_Length = 0;
  // Tail_Duration is the ending down ramping of the session
  unsigned int Tail_Duration = 15;
  // Calculate Smoother number for Sigmoid_Length of time
  unsigned int Tail_Length = 0;
  unsigned int Step = 0;
  Init_Output_Timing(TAU);
  if (Duration < 60)
  {
  Rampless_Stimulate(AC_Amplitude, DC_Amplitude, Frequency, Duration);
  }
  else
  {
  // Instead of calculating 101*Sigmoid_Multiple/1000
  // I will directly use 15 seconds.
  Duration = Duration-Tail_Duration;
  while (Session_Length < Duration)
  {
     // In order to measure loop period, Turn on Board_LED
     // Measure over LED401 R413
     Board_LED = 1;
     // In order to measure loop period, Turn on p5_7 Board LED
     //    p5_7 = 1;
    if (bit.TickISR)
    { 
      Session_Counter ++;
      Sigmoid_Length ++;
     // Counts Session length in seconds. Seconds counted with 
     // ms pulses from TimerB ISR
      if (Session_Counter >= 1000)
      {
        Session_Counter = 0;
        Session_Length ++;
      }
      bit.TickISR = 0;
    }
    // Calculate Smoother number for Sigmoid_Length of time
    // which is 101*150ms
    if (Session_Length < Tail_Duration)
    {
    // Count for delivering Sigmoid Data
    // We have 103 data points, and willing to have 15seconds ramp.
    // During start, at each 150mS period, Sigmoid Data Scaling should be done.
    // Sigmoid_Multiple is the variable that holds scaling period.
    // It is taken to be 150mS
     if (Sigmoid_Length >= Sigmoid_Counter)
      {
        Ramp_Count ++;
        Sigmoid_Counter = Sigmoid_Counter + Sigmoid_Multiple;
        // At Sigmoid_Multiple times, get a Sigmoid_Wave data for scaling
        Smoother = Sigmoid_Wave_tab [Ramp_Count];  
        Smoother = Smoother/10;
      }
    }
    else
    {
      Smoother = 100;
    }
    if (Let_Wave_Out)
    {
      // Took 16uS from p5_7 = 1; line.
      // In order to measure loop period, Turn on Board_LED
      // Board_LED = 1;
      // When subsampled 4 times, Frequency of the generated SineWave 
      // Increases to 32 Hz, Instead of 8Hz 500 data points wave.
      // Not so good.
      // Achieved 75 Hz by subsampling quad. DCO=4Mhz.
      // Use subsampling to generate waves of a wider frequency range.
      // Could achieve 930mhz with TAU=32000.
      // So, Step++ could have been used to get slower and higher
      // resolution waves.
      Step = Step + SubSamples;
      // Could achieved 85 Hz. Very Stepwise.
      // Step = Step + 20;
      // Got 17 Hz sine wave Mode2, no calculations. TAU=400 DCO= 2Mhz
      // Got 8.6 Hz sine wave Mode4, integer division. TAU=400 DCO= 2Mhz
      // Step++;
      Let_Wave_Out = 0;
//    DAC_Write(2, Step, scaled_AC_Amplitude, scaled_DC_Amplitude);
      DAC_Write(2, Step, 0, scaled_DC_Amplitude);
      // Error Beacon will light when there is a current drive error.
      Error_Beacon = XTR_Error;
      if (Step >= 500)
      {
        Step = 0;
      }
      // Took 1.316 mS when frequency is set to 197 Hz.
      // Took 106 uS when frequency is set to 1 Hz.
      // Took 1000uS to process
      // Took about 170uS when using Mode2, no calculations.
      // Took 160 uS, when Double operations were converted to 
      // integers and no calculation!
      // Took 440 uS with Integer division for scaling.
      // In order to measure loop period, Turn off Board_LED
      // Board_LED = 0; 
    }
    // Took 2.5uS from Board_LED = 0; line.
    // In order to measure loop period, Turn off p5_7 Board LED
    //    p5_7 = 0;
    // In order to measure loop period, Turn on Board_LED
    Board_LED = 0;
}

// Reset the variables.
Session_Counter = 0;
Sigmoid_Length = 0;
Sigmoid_Counter = 0;
Ramp_Count = 0;
Smoother = 0;
Error_Beacon_off ();

// In order to end the session with a ramp down function, this
// Tail algorithm will be used. Tail_Duration=15, normally.
  while (Tail_Length < Tail_Duration)
  {
    if (bit.TickISR)
    { 
      Session_Counter ++;
      Sigmoid_Length ++;
      // Counts Session length in seconds. Seconds counted with 
      // ms pulses from TimerB ISR
      if (Session_Counter >= 1000)
      {
        Session_Counter = 0;
        Tail_Length ++;
      }
      bit.TickISR = 0;
    }
    // Calculate Smoother number for Sigmoid_Length of time
    // which is 101*150ms
    if (Tail_Length <= 101*Sigmoid_Multiple)
    {
    // Count for delivering Sigmoid Data
    // We have 103 data points, and willing to have 15seconds ramp.
    // During start, at each 150mS period, Sigmoid Data Scaling should be done.
    // Sigmoid_Multiple is the variable that holds scaling period.
    // It is taken to be 150mS
     if (Sigmoid_Length >= Sigmoid_Counter)
      {
        Ramp_Count ++;
        Sigmoid_Counter = Sigmoid_Counter + Sigmoid_Multiple;
        // At Sigmoid_Multiple times, get a Sigmoid_Wave data for scaling
        // Reverse the Smoother selection process
        // Reverse the Sigmoid function
        Smoother = Sigmoid_Wave_tab [101-Ramp_Count];  
        Smoother = Smoother/10;
      }
    }
    else
    {
      Smoother = 100;
    }
    if (Let_Wave_Out)
    {
      Step = Step + SubSamples;
      Let_Wave_Out = 0;
//    DAC_Write(2, Step, scaled_AC_Amplitude, scaled_DC_Amplitude);
      DAC_Write(2, Step, 0, scaled_DC_Amplitude);
      if (Step >= 500)
      {
        Step = 0;
      }
    }
  }
    // Graceful Ending
    // Set Output to Zero!
    // Resulted in 24mV output. Acceptable.
      DAC_Write(5, Step, scaled_AC_Amplitude, scaled_DC_Amplitude);
      Error_Beacon_off ();
Halt_Output_Timing();
}
}
// Timer A0 interrupt service routine
#pragma vector=TIMERA0_VECTOR
__interrupt void Timer_A(void)
{
  // Flag to set wave-number out
  Let_Wave_Out = 1;
  // Measure wave timing over p5_0 ic401 pin12
  p5_1 ^= 1;
}