/*This file has been prepared for Doxygen automatic documentation generation.*/
/*! \file *********************************************************************
 *
* TESsaNova: tDCS TransCranial DC Brain Stimulator
* Developed for research studeies at MAKELab
*
* Board Definition and Pin Connections File
*
* Adnan Kurt
* Teknofil
* 19Aug. 2013
* Zekeriyakoy, Istanbul
* - File:               TESsaNova_Board_Definition_File_19Aug2013.c
* - Compiler:           IAR EWBMSP430 5.40
* - Supported devices:  MSP430F149
* - Circuit:            TESsaNova_19Nov2011_F.sch
*
*  \author    AdKu            \n
*             Adnan Kurt      \n
*             Teknofil        \n
*             19Aug. 2013     \n
*             Zekeriyakoy, Istanbul
*
*  Integer type Example
*  Binary  1010b, b'1010'
*  Octal  1234q, q'1234'
*  Decimal  1234, -1, d'1234'
*  Hexadecimal  0FFFFh, 0xFFFF, h'FFFF'
*  
*  More pins available. Complete those 
*
*******************************************************************************/

// Pin Definitions 
// Find PCB connector layout on 19Aug2013 notes
// This naming convention is compatible with schematic
# define  ZAP1            0x02 // 0000 0010b p1  // Triggers Stimulation
# define  BZZR            0x04 // 0000 0100b p1  // Amplified Buzzer
# define  INCREMENT       0x08 // 0000 1000b p1  // Increment Switch 
# define  DECREMENT       0x10 // 0001 0000b p1  // Decrement Switch
# define  ZAP             0x20 // 0010 0000b p1  // Current Out Monitor ?
# define  BRLY            0x40 // 0100 0000b p1  // Relay on Board -Human Model
# define  XTR_ERROR       0x80 // 1000 0000b p1  // XTR Control Error Flag
# define  IA_             0x01 // 0000 0001b p2  // BCD data A 7Segment LED
# define  IB_             0x02 // 0000 0010b p2  // BCD data B 7Segment LED
# define  IC_             0x04 // 0000 0100b p2  // BCD data C 7Segment LED
# define  ID_             0x08 // 0000 1000b p2  // BCD data D 7Segment LED
# define  LEH_            0x10 // 0001 0000b p2  // High Digit Enable
# define  LEL_            0x20 // 0010 0000b p2  // Low Digit Enable
# define  BLED            0x40 // 0100 0000b p2  // LED on Board
# define  NOTSYNC_        0x01 // 0000 0001b p3  // SPI sync
# define  DIN_            0x02 // 0000 0010b p3  // DAC Data -SPI
# define  SCLK_           0x08 // 0000 1000b p3  // SPI clk
# define  LELL_           0x10 // 0001 0000b p3  // LowerDigit  enable
# define  LELLL_          0x20 // 0010 0000b p3  // LowestDigit  enable
# define  Beat            0x02 // 0000 0010b p4  // Heart Beat LED-pwm
# define  D4_             0x04 // 0000 0100b p4  // LCD Data D4
# define  D5_             0x08 // 0000 1000b p4  // LCD Data D5
# define  D6_             0x10 // 0001 0000b p4  // LCD Data D6
# define  D7_             0x20 // 0010 0000b p4  // LCD Data D7
# define  ELCD_           0x40 // 0100 0000b p4  // Enable LCD
# define  RS_             0x80 // 1000 0000b p4  // Reset Signal LCD
// R/W of LCD pin to be connected to GND
# define  OD              0x08 // 0000 1000b p5  // Output Disable -XTR off
# define  CUSA            0x01 // 0000 0001b p6  // Output Current Sample
# define  AMPL            0x02 // 0000 0010b p6  // Amplitude Set Pot
# define  DCOS            0x04 // 0000 0100b p6  // DC Offset Set Pot
# define  FREQ            0x08 // 0000 1000b p6  // Frequency Set Pot
# define  BATT_SAMPLE     0x20 // 0010 0000b p6  // Battery Monitor
# define  p5_0_           0x01 // 0000 0001b p5  // Buffered p5.0
# define  p5_1_           0x02 // 0000 0010b p5  // Buffered p5.1
# define  p5_2_           0x04 // 0000 0100b p5  // Buffered p5.2
# define  p5_6_           0x40 // 0100 0000b p5  // p5.6
# define  p5_7_           0x80 // 1000 0000b p5  // p5.7
# define  p4_0_           0x01 // 0000 0001b p4  // p4.0
# define  p1_0_           0x01 // 0000 0001b p1  // p1.0

// This naming scheme is to enhance readability in the program
# define  Stimulation_trigger   P1IN_bit.P1            
// 0x02 // 0000 0010b p1  // Triggers Stimulation
# define  Buzzer                P1OUT_bit.P2 
// 0x04 // 0000 0100b p1  // Amplified Buzzer
# define  Increment             P1IN_bit.P3 
// 0x08 // 0000 1000b p1  // Increment Switch 
# define  Decrement             P1IN_bit.P4
// 0x10 // 0001 0000b p1  // Decrement Switch
# define  Error_Beacon          P1OUT_bit.P5             
// 0x20 // 0010 0000b p1  // Blinks at inconsistent current outputs
# define  Board_Relay           P1OUT_bit.P6 
// 0x40 // 0100 0000b p1  // Relay on Board -Human Model-Subject Switcher
# define  XTR_Error             P1IN_bit.P7 
// 0x80 // 1000 0000b p1  // XTR Control Error Flag
# define  IA                    P2OUT_bit.P0
// 0x01 // 0000 0001b p2  // BCD data A 7Segment LED
# define  IB                    P2OUT_bit.P1 
// 0x02 // 0000 0010b p2  // BCD data B 7Segment LED
# define  IC                    P2OUT_bit.P2
// 0x04 // 0000 0100b p2  // BCD data C 7Segment LED
# define  ID                    P2OUT_bit.P3
// 0x08 // 0000 1000b p2  // BCD data D 7Segment LED
# define  LEH                   P2OUT_bit.P4
// 0x10 // 0001 0000b p2  // High Digit Enable
# define  LEL                   P2OUT_bit.P5
// 0x20 // 0010 0000b p2  // Low Digit Enable
# define  LELL                  P3OUT_bit.P4
// 0x10 // 0001 0000b p3  // LowerDigit  enable
# define  LELLL                 P3OUT_bit.P5 
// 0x20 // 0010 0000b p3  // LowestDigit  enable
# define  Board_LED             P2OUT_bit.P6
// 0x40 // 0100 0000b p2  // LED on Board
# define  NOTSYNC               P3OUT_bit.P0 
// 0x01 // 0000 0001b p3  // SPI sync
# define  DIN                   P3OUT_bit.P1
// 0x02 // 0000 0010b p3  // DAC Data -SPI
# define  SCLK                  P3OUT_bit.P3
// 0x08 // 0000 1000b p3  // SPI clk
# define  HeartBeat_LED         P4OUT_bit.P1           
// 0x02 // 0000 0010b p4  // Heart Beat LED-pwm
# define  D4                    P4OUT_bit.P2   // LCD
# define  D5                    P4OUT_bit.P3   // LCD
# define  D6                    P4OUT_bit.P4   // LCD
# define  D7                    P4OUT_bit.P5   // LCD
# define  EN                    P4OUT_bit.P6   // LCD
# define  RS                    P4OUT_bit.P7   // LCD
// R/W of LCD pin to be connected to GND
# define  XTR_Out_Disable       P5OUT_bit.P3              
// 0x08 // 0000 1000b p5  // Output Disable -XTR off
# define  Current_Sample_Read   P6IN_bit.P0           
// 0x01 // 0000 0001b p6  // Output Current Sample
# define  Amplitude_Set_Pot     P6IN_bit.P1
// 0x02 // 0000 0010b p6  // Amplitude Set Pot
# define  DC_Offset_Set_Pot     P6IN_bit.P2
// 0x04 // 0000 0100b p6  // DC Offset Set Pot
# define  Freq_Set_Pot          P6IN_bit.P3
// 0x08 // 0000 1000b p6  // Frequency Set Pot
# define  Battery_Monitor       P6IN_bit.P5
// 0x20 // 0010 0000b p6  // Battery Monitor
# define  p5_0                  P5OUT_bit.P0 
// 0x01 // 0000 0001b p5  // Buffered p5.0
# define  Stimulation_Marker    P5OUT_bit.P1             
// 0x20 // 0010 0000b p1  // Stimulation Synch Output
# define  p5_1                  P5OUT_bit.P1
// 0x02 // 0000 0010b p5  // Buffered p5.1 also used for clock monitoring
# define  p5_2                  P5OUT_bit.P2 
// 0x04 // 0000 0100b p5  // Buffered p5.2
# define  p5_6                  P5IN_bit.P5 
// 0x20 // 0010 0000b p5  // p5.6
# define  p5_7                  P5OUT_bit.P7 
// 0x20 // 0010 0000b p5  // p5.7 OnBoard activity Monitor
# define  p4_0                  P4OUT_bit.P0
// 0x80 // 0000 0001b p4  // p4.0
# define  p1_0                  P1OUT_bit.P0 
// 0x80 // 0000 0001b p1  // p1.0

void  Board_Setup (void)
{
  P1DIR =  p1_0_ | BZZR | BRLY | ZAP ;
  P1SEL =  0x00;
  P1OUT =  0x00;               
  P2DIR =  IA_ | IB_ | IC_ | ID_ | LEH_ | LEL_ | BLED ;
  P2SEL =  0x00;               
  P2OUT =  0x00;
  P3DIR =  NOTSYNC_ | DIN_ | SCLK_ | LELL_ | LELLL_ ;
  P3SEL =  DIN_ | SCLK_ ;     // Check out!
  P3OUT =  0x00;               
  P4DIR =  Beat | D4_ | D5_ | D6_ | D7_ | ELCD_ | RS_ ;
  P4SEL =  0x00;
  P4OUT =  0x00;
  P5DIR =  p5_0_ | p5_1_ | p5_2_ | p5_7_ | OD ;
  P5SEL =  0x00;
  P5OUT =  0x00;
  P6DIR =  0x00;
  P6SEL =  CUSA | AMPL | DCOS | FREQ | BATT_SAMPLE ;
  P6OUT =  0x00;
}
