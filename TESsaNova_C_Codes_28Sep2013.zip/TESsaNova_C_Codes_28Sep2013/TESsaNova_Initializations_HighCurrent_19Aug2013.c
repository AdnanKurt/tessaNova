/*This file has been prepared for Doxygen automatic documentation generation.*/
/*! \file *********************************************************************
 *
* TESsaNova: tDCS TransCranial DC Brain Stimulator
* Developed for research studeies at MAKELab
*
* Parameters Initializations File
*
* Adnan Kurt
* Teknofil
* 22Aug. 2013
* Zekeriyakoy, Istanbul
* - File:               TESsaNova_Initializations_19Aug2013.c
* - Supported devices:  MSP430F149
* - Circuit:            TESsaNova_19Nov2011_F.sch
*
*  \author    AdKu            \n
*             Adnan Kurt      \n
*             Teknofil        \n
*             19Aug. 2013     \n
*             Zekeriyakoy, Istanbul
*
*
*******************************************************************************/

# define  SIZE 100  //waveform period

// variable declerations
# define _100us  14         // 4 about 1oous
# define _10us   5          // 1 about 25us
unsigned int  wait_delay;   // in 1ms units
unsigned int  tick_count_1;
unsigned int  tick_count_2;

double Sense_i_read;
double Sense_i_value;
double Vs_Read_value;
double Vs_Read_Read;
double Board_Temperature;
double NoiseTest1;
double NoiseTest2;
double NoiseTest3;
double NoiseTest4;
double NoiseTest5;
void   Clock_Set (void);
void   Loop_Timer(void);
int    Process;
int    Emergency;
int    errorValue;
int Stimulation_On;
unsigned int tick_count;
int Looping;
double MaxAmplitude;
double MaxDCOffset;
double MaxFrequency;
double MaxVoltage;
double MaxCurrent;
unsigned int Period;
unsigned int Duration;
unsigned int Compliance_Voltage;
int Stimulation_Mode;
int Last_RMS_Current;
int Test_Amplitude;
int Test_Duration;

// default parameters
void tDCS_Parameters (void) {
  tick_count = 0;                   // TimerA loop clock count
  wait_delay = 10;                  // number of TimerA IT loops to wait
				    // 5.0 ms/Tick
  Stimulation_On = 0;
  Looping = 1;			    // During Process Loops, it is 0.
  MaxAmplitude = 4000.0;            // Maximum AC Stimulation Current in uA
  MaxDCOffset = 4000.0;             // Maximum DC Stimulation Current in uA
  MaxFrequency = 800.0;             // Maximum Stimulation Frequency in cHz
  MaxVoltage = 1800;                // Maximum Supply Voltage in cV
  MaxCurrent = 5000.0;              // Maximum Output Current Read in uA

  Compliance_Voltage = 20;    // Kept for Consistency in Flash
  Stimulation_Mode = 1;       // Kept for Consistency in Flash
}

volatile struct
{
  unsigned char TickISR:1;          // ISR Handling
} bit;

void wait (int wait_delay){	       // 1 ms/tick set in PP_Loop_Timer.c
//    ledB ^= 1;                       // delay measurement
                                       // -temporary on p1.6 check from the list
    tick_count_1 = tick_count;
    tick_count_2 = tick_count-tick_count_1;
    while (tick_count_2 < wait_delay){
    tick_count_2 = tick_count-tick_count_1;
  }
//    ledB = 1;                        // delay measurement
}

void Beep (int length, int freq)
{
  int l = length;
  while ( l >1 )
  {
    Buzzer ^= 1;
    wait ( freq );
    l --;
  }
}

void Error_Beacon_on (void)
{
  // LED is connected to inverting output of CD4049 IC601
  Error_Beacon = 0;
}

void Error_Beacon_off (void)
{
  // LED is connected to inverting output of CD4049 IC601
  Error_Beacon = 1;
}

