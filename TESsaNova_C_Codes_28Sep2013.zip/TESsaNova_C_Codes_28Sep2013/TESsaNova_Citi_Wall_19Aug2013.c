/*This file has been prepared for Doxygen automatic documentation generation.*/
/*! \file *********************************************************************
 *
* TESsaNova: tDCS TransCranial DC Brain Stimulator
* Developed for research studeies at MAKELab
*
* LCD User Interface File
* modified version of Andreas Dannenberg   
*
* Adnan Kurt
* Teknofil
* 19Aug. 2013
* Zekeriyakoy, Istanbul
* - File:               TESsaNova_Board_Definition_File_19Aug2013.c
* - Compiler:           IAR EWBMSP430 5.40
* - Supported devices:  MSP430F149
* - Circuit:            TESsaNova_19Nov2011_F.sch
*
*  \author    AdKu            \n
*             Adnan Kurt      \n
*             Teknofil        \n
*             19Aug. 2013     \n
*             Zekeriyakoy, Istanbul
*             
* NB. This program must be updated with a better formed and documented one.
* 
*******************************************************************************/

// #include <msp430x22x4.h>
// #include "Citi_Wall.h"
// #include <string.h>

void initDisplay();
void putc(char c);
void clearDisplay();
void printDecimal(int Number);
void printHex(unsigned int Number);
void printString(char *String);
void gotoSecondLine();
void printByte(unsigned int theByte);

#define bitset(var,bitno) ((var) |= 1 << (bitno))
#define bitclr(var,bitno) ((var) &= ~(1 << (bitno)))

// #define          LCD_Data           P2OUT
#define          _100us             14      // 4 about 1oous  1 at 2Mhz
#define          _10us              5       // 1 about 25us   1 at 2Mhz
#define          EE                 3       //3        //P2.3
#define          RSS                2       //2        //P2.2
#define          CR                 0x0d
#define          LF                 0x0a
#define		DISP_ON			0x0c	        //LCD control constants
#define		DISP_OFF		0x08	        //
#define		CLR_DISP		0x01    	//
#define		CUR_HOME		0x02	        //
#define		CUR_LEFT		0x10	        //
#define		ENTRY_INC		0x06            //
#define		DD_RAM_ADDR		0x80	        //
#define		DD_RAM_ADDR2		0xc0	        //
#define		DD_RAM_ADDR3		0x28	        //
#define		CG_RAM_ADDR		0x40	        //

int LCD_REG;
            
void Delay (unsigned int a);
void Delayx100us(unsigned char b);
void SEND_CHAR (unsigned char c);
void SEND_CMD (unsigned char e);
void _E(void);
void InitLCD(void);

void LCD_Con (void) {
  D7 = (LCD_REG & BIT7) / 0x4F;
  D6 = (LCD_REG & BIT6) / 0x2F;
  D5 = (LCD_REG & BIT5) / 0x1F;
  D4 = (LCD_REG & BIT4) / 0xF;
  EN = (LCD_REG & BIT3) / 0x8;
  RS = (LCD_REG & BIT2) / 0x4;
}

void initDisplay() {
    InitLCD();
    clearDisplay();
}
void putc(char c) {
    SEND_CHAR(c);
}
void oha(char a) {
}
void clearDisplay() {
    SEND_CMD(CLR_DISP);
    Delayx100us(10);
}
void Back() {
    SEND_CMD(CUR_LEFT);
    Delayx100us(1);
}
void gotoSecondLine() {
//    SEND_CMD(CLR_DISP);
    SEND_CMD(DD_RAM_ADDR2);
}
void gotoFirstLine() {          // Check the operation. I've added it. AK 
    SEND_CMD(DD_RAM_ADDR);
}
void printString(char *String) {
  while(*String)
    putc(*String++);
}
void printgString(char *Gtring) {
    oha(*Gtring++);
    oha(*Gtring++);
    oha(*Gtring++);
    oha(*Gtring++);
    oha(*Gtring++);
    while(*Gtring)
    putc(*Gtring++);
}
char HexDigit(int digitvalue) {
  if (digitvalue < 10)
    return(digitvalue + '0');
  else
    return(digitvalue + 'A' - 10);
}
void printByte(unsigned int theByte) {
  char HexBuffer[3];
  HexBuffer[2] = 0;
  HexBuffer[1] = HexDigit(theByte & 0x000f);
  theByte = theByte >> 4;
  HexBuffer[0] = HexDigit(theByte & 0x000f);
  printString(HexBuffer);
}
void printHex(unsigned int Number) {
  char HexBuffer[5];
  HexBuffer[4] = 0;
  HexBuffer[3] = HexDigit(Number & 0x000f);
  Number = Number >> 4;
  HexBuffer[2] = HexDigit(Number & 0x000f);
  Number = Number >> 4;
  HexBuffer[1] = HexDigit(Number & 0x000f);
  Number = Number >> 4;
  HexBuffer[0] = HexDigit(Number & 0x000f);
  printString(HexBuffer);
}

void print4Decimal(int Number) {
  // need to move to long int to account for
  // negative 32768
  char DecimalBuffer[10];
  int lNumber = Number;
  
  DecimalBuffer[9] = '\0';      // correct termination AK
  DecimalBuffer[8] = (lNumber % 10)+'0';
  lNumber = lNumber / 10;
  DecimalBuffer[7] = (lNumber % 10)+'0';
  lNumber = lNumber / 10;
  DecimalBuffer[6] = (lNumber % 10)+'0';
  lNumber = lNumber / 10;
  DecimalBuffer[5] = (lNumber % 10)+'0';
  DecimalBuffer[4] = '0';
  DecimalBuffer[3] = '0';
  DecimalBuffer[2] = '0';
  DecimalBuffer[1] = '0';
  DecimalBuffer[0] = '0';
  printgString(DecimalBuffer);
}

void printDecimal(int Number) {
  // need to move to long int to account for
  // negative 32768
  char DecimalBuffer[9];
  long lNumber = Number;
  DecimalBuffer[8] = '\0';      // correct termination AK
  DecimalBuffer[7] = (lNumber % 10)+'0';
  lNumber = lNumber / 10;
  DecimalBuffer[6] = (lNumber % 10)+'0';
  lNumber = lNumber / 10;
  DecimalBuffer[5] = (lNumber % 10)+'0';
  DecimalBuffer[4] = '0';
  DecimalBuffer[3] = '0';
  DecimalBuffer[2] = '0';
  DecimalBuffer[1] = '0';
  DecimalBuffer[0] = '0';
  printgString(DecimalBuffer);
}
/*
void printDecimal(int Number) {
  // need to move to long int to account for
  // negative 32768
  char DecimalBuffer[7];
  long lNumber = Number;
  DecimalBuffer[6] = 0;
  if (lNumber < 0) {
    DecimalBuffer[0] = '-';
    lNumber = -lNumber;
  } else
    DecimalBuffer[0] = '+';
  DecimalBuffer[5] = (lNumber % 10)+'0';
  lNumber = lNumber / 10;
  DecimalBuffer[4] = (lNumber % 10)+'0';
  lNumber = lNumber / 10;
  DecimalBuffer[3] = (lNumber % 10)+'0';
  lNumber = lNumber / 10;
  DecimalBuffer[2] = (lNumber % 10)+'0';
  lNumber = lNumber / 10;
  DecimalBuffer[1] = (lNumber % 10)+'0';
  printString(DecimalBuffer);
}

void printDecimal(int Number) {
  // need to move to long int to account for
  // negative 32768
  // Reformulated to get only 3 digits. No sign. AK 
  char DecimalBuffer[3];
  int lNumber = Number;
  DecimalBuffer[2] = (lNumber % 10)+'0';
  lNumber = lNumber / 10;
  DecimalBuffer[1] = (lNumber % 10)+'0';
  lNumber = lNumber / 10;
  DecimalBuffer[0] = (lNumber % 10)+'0';
  printString(DecimalBuffer);
}
*/

void Delay (unsigned int a)
{
  int k;
  for (k=0 ; k != a; ++k) {
/* 
    _NOP();
    _NOP();
    _NOP();
    _NOP();
*/
  }
}

void Delayx100us(unsigned char b)
{
  int j;
  for (j=0; j!=b; ++j) {
//  ledB ^= 1;                              // delay measurement 
                                            // -temporary on p1.7
                                            // should read 100us pulses
    Delay (_100us);
}
//  ledB_off();                             // delay measurement 
}

void _E(void)
{
  bitset(LCD_REG,EE);		//toggle E for LCD
        LCD_Con ();
	Delay(_10us);
	bitclr(LCD_REG,EE);
        LCD_Con ();
}

void SEND_CHAR (unsigned char d)
{
        int temp;
	Delayx100us(2);                 //.5ms	
	temp = d & 0xf0;		//get upper nibble	
	LCD_REG &= 0x0f;
	LCD_Con ();
	LCD_REG |= temp;
	LCD_Con ();
	bitset(LCD_REG,RSS);            //set LCD to data mode
        LCD_Con ();
	_E();                           //toggle E for LCD
	temp = d & 0x0f;
	temp = temp << 4;               //get down nibble
	LCD_REG &= 0x0f;
	LCD_Con ();
	LCD_REG |= temp;
	LCD_Con ();
	bitset(LCD_REG,RSS);   	        //set LCD to data mode
        LCD_Con ();
	_E();                           //toggle E for LCD
}

void SEND_CMD (unsigned char e)
{
        int temp;
        Delay(_10us);
        Delay(_10us);
//	Delayx100us(2);                 //10ms
	temp = e & 0xf0;		//get upper nibble	
	LCD_REG &= 0x0f;
	LCD_Con ();
	LCD_REG |= temp;      
        LCD_Con ();                     //send CMD to LCD
	bitclr(LCD_REG,RSS);     	//set LCD to CMD mode
        LCD_Con ();
	_E();                           //toggle E for LCD
	temp = e & 0x0f;
	temp = temp << 4;               //get down nibble
	LCD_REG &= 0x0f;
	LCD_Con ();
	LCD_REG |= temp;
	LCD_Con ();
	bitclr(LCD_REG,RSS);   	        //set LCD to CMD mode
        LCD_Con ();
	_E();                           //toggle E for LCD
}

void InitLCD(void)
{
    bitclr(LCD_REG,RSS);
    LCD_Con ();
    Delayx100us(25);                   //Delay 100ms
    Delayx100us(25);
    Delayx100us(25);
    Delayx100us(25);
    LCD_REG |= BIT4 | BIT5;    
    LCD_Con ();        //D7-D4 = 0011
    LCD_REG &= ~BIT6 & ~BIT7;
    LCD_Con ();
    _E();                               //toggle E for LCD
    Delayx100us(10);                    //10ms
    _E();                               //toggle E for LCD
    Delayx100us(10);                    //10ms
    _E();                               //toggle E for LCD
    Delayx100us(10);                    //10ms
    LCD_REG &= ~BIT4;
       LCD_Con ();
    _E();                               //toggle E for LCD

    SEND_CMD(DISP_ON);
    SEND_CMD(CLR_DISP);
    Delayx100us(25);
    Delayx100us(25);
    Delayx100us(25);
    Delayx100us(25);
}


