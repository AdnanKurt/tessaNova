//****************************************************************************
//
//  newEsti_FlashWrite_04Nov2012.c
//
//  newEsti -stimulation parameters to be written and fetched
//  From the A segment of Info Memory
//
//  MSP430F14x Demo - Flash In-System Programming, BlockWrite
//
//  Description: This program first copies the FlashWrite routine to RAM, then
//  erases flash seg A, then it increments all values in seg A using the 64
//  byte block write mode.
//
//  Assumed default MCLK = DCO ~2000 kHz.
//  Minimum RAM requirement = 512 bytes 
//
//               MSP430F149
//            -----------------
//        /|\|              XIN|-
//         | |                 |
//         --|RST          XOUT|-
//           |                 |
//
//  H. Grewal / L. Westlund
//  Texas Instruments Inc.
//  Jun 2006
//
// Adopted from Grewal&Westlund, to work with newEsti. -stimulation parameters 
// to be written to Info Memory. When all the A segment is used, the
// Flash segment block will be erased. So, the number erase cycles attempted
// to be decreased by 1/64. ReadFlash routine reads the last value written
// to the flash by comparing to 0xFFFF value. An index is generated, and
// a value for loops that was most recently written.
//
// Adnan Kurt
// Teknofil
// 04Apr2011
// Advise by A.Tugrul Anildi
// Revised for newEsti
// 05Nov2012
// Adnan Kurt
//
//
// Parameter storage reformed with a series of storing items. 7 parameters
// were stored sequentially, and recovered in a reverse fashion.
// Free space were checked and, serial storage and serial fetching
// is done. Needs to be correctly debugged.
//
// 23Dec2012
//
// Debugged and corrected. Working fine.
// AdKU
// 28Dec2012
//
// Dangerously mixes up after filling the flash space. Have to solve the
// operational fallacies by careful debugging.
// Found two places where the initialization of pointers were not done
// appropriately.
// AdKu
// 26Jun2013
//
//******************************************************************************

// Global variables
unsigned int pi  = 0x3145;
unsigned int Flash_Start= 0x1234;
unsigned int Flash_End = 0xCDEF;
unsigned int Test_Flash_Start;
/*
unsigned int Duration = 2;             // default 16-bit value to write to segment A 
unsigned int Laser_Current = 10;       // default 16-bit value to write to segment A  
unsigned int Period = 20;              // default 16-bit value to write to segment A  
unsigned int OnTime = 25;              // default 16-bit value to write to segment A   
unsigned int OffTime = 75;             // default 16-bit value to write to segment A 
unsigned int Compliance_Voltage = 10;  // kept for consistency. 
int Stimulation_Mode = 1;              // kept for consistency.
*/
/*
// To place factory data to info memory
// const unsigned char port_bit @ 0x1800 = BIT0;
const unsigned char _pi @ 0x1000 = 0x31;
const unsigned char _pj @ 0x1001 = 0x45;
const unsigned int _Flash_Start @ 0x1002 = 1234;
const unsigned int _Duration @ 0x1004 = 2;
const unsigned int _Laser_Current @ 0x1006 = 0;
const unsigned int _Period @ 0x1008 = 10;
const unsigned int _OnTime @ 0x100A = 20;
const unsigned int _OffTime @ 0x100C = 80;
const unsigned int _Compliance_Voltage @ 0x100E = 2;
const unsigned int _Stimulation_Mode @ 0x1010 = 1;
const unsigned int _Flash_End @ 0x1012 = 0xCDEF;

#pragma location = 0x1000
const unsigned int _pi  = 0x3145;
const unsigned int _Flash_Start= 1234;
const unsigned int _Duration = 2;
const unsigned int _Laser_Current = 0;
const unsigned int _Period = 10;
const unsigned int _OnTime = 20;
const unsigned int _OffTime = 80;
const unsigned int _Compliance_Voltage = 2;
const unsigned int _Stimulation_Mode = 1;
const unsigned int _Flash_End = 0xCDEF;
*/

short * Flash_ptr;            // Flash pointer
int Pointer_First;
int Pointer_Second;
int m = 0;
int index_LV = 0;
int set_fault;

// Function prototypes
void FlashWrite();
void FlashRead();
void End_of_FlashWrite();

void Memorize (short Duration, short Laser_Current, short Period, 
               short OnTime, short OffTime, short Compliance_Voltage, 
               short Stimulation_Mode)
{
  _DINT();                                  // Disable Interrupts
    Pointer_First = 0;
    Pointer_Second = 0;
    m = 0;
    Flash_ptr = (short *) 0x1000;
    Pointer_First = *Flash_ptr; 
    if (Pointer_First != 0xFFFF)
    {
    Pointer_Second = *Flash_ptr;  // This statement was missing, I think will help.
      while (Pointer_Second != 0xFFFF)      // Find the free space
      {
        Flash_ptr++;           		    // Initialize Flash pointer
	m++;
        Pointer_Second = *Flash_ptr;        // Set the pointer 
      }
      index_LV = m;
    }
    else
    {
      index_LV = 0;
    }
    if (index_LV >= 0x33)                   // If enough space cease to exist 96bytes
    {
      Flash_ptr = (short *) 0x1000;         // Initialize Flash pointer
      FCTL2 = FWKEY + FSSEL_2 + FN3;        // SMCLK/16 for Flash Timing Generator
      FCTL1 = FWKEY + ERASE;                // Set Erase bit
      FCTL3 = FWKEY;                        // Clear Lock bit
      *Flash_ptr = 0;                       // Dummy write to erase Flash segment
      while(!(FCTL3 & WAIT));               // WAIT until Flash is ready
      while(FCTL3 & BUSY);                  // WAIT until Flash is ready
      FCTL1 = FWKEY;
      FCTL3 = FWKEY + LOCK;
      /*
      Flash_ptr = (short *) 0x1080;         // Initialize Flash pointer
      FCTL2 = FWKEY + FSSEL_2 + FN3;        // SMCLK/16 for Flash Timing Generator
      FCTL1 = FWKEY + ERASE;                // Set Erase bit
      FCTL3 = FWKEY;                        // Clear Lock bit
      *Flash_ptr = 0;                       // Dummy write to erase Flash segment
      while(!(FCTL3 & WAIT));               // WAIT until Flash is ready
      while(FCTL3 & BUSY);                  // WAIT until Flash is ready
      FCTL1 = FWKEY;
      FCTL3 = FWKEY + LOCK;
      */
      _EINT();
      index_LV = 0;
    }
  FlashWrite(0x3145, index_LV + 0);
    FlashWrite(Flash_Start, index_LV + 1);
      FlashWrite(Duration, index_LV + 2);
        FlashWrite(Laser_Current, index_LV + 3);
          FlashWrite(Period, index_LV + 4);
            FlashWrite(OnTime, index_LV + 5);
              FlashWrite(OffTime, index_LV + 6);
                FlashWrite(Compliance_Voltage, index_LV + 7);
                  FlashWrite(Stimulation_Mode, index_LV + 8);
                    FlashWrite(Flash_End, index_LV + 9);
     
                                            // SET BREAKPOINT HERE
  _EINT();                                  // Enable Interrupts
}

// If Info memory is free, then initialize with original data.
void Test_Info_Memory (void)
{
     Flash_ptr = (short *) 0x1000;
     Test_Flash_Start = *Flash_ptr;
     if (Test_Flash_Start == 0xFFFF)
     {
       Memorize (Duration, Laser_Current, Period, 
               OnTime, OffTime, Compliance_Voltage, 
               Stimulation_Mode); // This must be done before anything else.
     }
}
  
void Remember_Parameters(void)
{
    Pointer_First = 0;
    Pointer_Second = 0;
    m = 0;
    Flash_ptr = (short *) 0x1000;
    Pointer_Second = *Flash_ptr;  // This statement was missing, I think will help.
    while (Pointer_Second != 0xFFFF) 
    {
	Pointer_First = *Flash_ptr; 
        Flash_ptr++;           		     // Initialize Flash pointer
        m++;
        Pointer_Second = *Flash_ptr; 
    }
    int Test_Flash_End = Pointer_First;
    Flash_ptr--; 
    Flash_ptr--; 
    Stimulation_Mode = *Flash_ptr;
    Flash_ptr--; 
    Compliance_Voltage = *Flash_ptr;
    Flash_ptr--; 
    OffTime = *Flash_ptr;
    Flash_ptr--; 
    OnTime = *Flash_ptr;
    Flash_ptr--; 
    Period = *Flash_ptr;
    Flash_ptr--; 
    Laser_Current = *Flash_ptr;
    Flash_ptr--; 
    Duration = *Flash_ptr;
    Flash_ptr--; 
    int Test_Flash_Start = *Flash_ptr;
    
    _NOP();                            	     // SET BREAKPOINT HERE
    if (m >= 64) 
    {
  Beep();
  wait(40);
  Beep();
	set_fault = 8;                       // Storage Error
    }
    if ((Stimulation_Mode == -1) 
        | (Test_Flash_End != 0xCDEF) 
          | (Test_Flash_Start != 0x1234))
    {
  Beep();
  wait(40);
  Beep();
  wait(100);
  Beep();
	set_fault = 8;                       // Storage Error
    }
}

void FlashWrite(int Memo, int index_LV)
{
  FCTL2 = FWKEY + FSSEL_2 + FN3;     	     // MCLK/2 for Flash Timing Generator
  FCTL1 = FWKEY + ERASE;                     // Set Erase bit
  FCTL3 = FWKEY;                             // Clear Lock bit
  Flash_ptr = (short*)0x1000 + index_LV ;    // Initialize Flash pointer
    if (index_LV == 0) 
    {
        Flash_ptr = (short*)0x1000;
    }					     // Initialize Flash pointer  
  while(FCTL3 & BUSY);                       // Check Flash BUSY bit
  FCTL1 = FWKEY + WRT;              	     // Enable write operation
  *Flash_ptr = Memo;  	                     // Write value to flash
  while(!(FCTL3 & WAIT));                    // WAIT until Flash is ready
  FCTL1 = FWKEY;                             // Clear BLKWRT & WRT bits
  while(FCTL3 & BUSY);                       // Check Flash BUSY bit
  FCTL3 = FWKEY + LOCK;                      // Reset LOCK bit
  return;                                    // Exits routine
}

void End_of_FlashWrite(){}                   // Marks end of FlashWrite

