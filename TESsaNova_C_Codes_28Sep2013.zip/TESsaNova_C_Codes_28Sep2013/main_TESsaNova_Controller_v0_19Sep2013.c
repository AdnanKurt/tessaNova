/*This file has been prepared for Doxygen automatic documentation generation.*/
/*! \file *********************************************************************
 *
* TESsaNova: tDCS TransCranial DC Brain Stimulator
* Developed for research studeies at MAKELab
*
* Main Control Code.
*
* Adnan Kurt
* Teknofil
* 19Aug. 2013
* Zekeriyakoy, Istanbul
*
* Skin Welding Laser_Controller has been rewritten, based on
* the studies documented in BioLaser_Controller_v1_11Feb12.c
*
* 
* - File:               main_TESsaNova_Controller_v0_19Aug2013.c
* - Compiler:           IAR EWBMSP430 5.40
* - Supported devices:  MSP430F149
* - Circuit:            TESsaNova_19Nov2011_F.sch
*
*  \author    AdKu            \n
*             Adnan Kurt      \n
*             Teknofil        \n
*             19Aug. 2013     \n
*             Zekeriyakoy, Istanbul
*             
*  $Name $
*  $Revision: 0 $
*  $RCSfile $
*  $Date:    11Feb2012         $
* "Store the total time used on flash memory." will not be implemented.
*
******************************************************************************/

# include <io430x14x.h>
# include <in430.h>
//# include <msp430x14x.h>
//# include <intrinsics.h>
# include <math.h>
# include <stdint.h>
# include <TESsaNova_Board_Definition_File_19Aug2013.c>
# include <TESsaNova_Initializations_19Aug2013.c>
# include <TESsaNova_Clock_Set_19Aug2013.c>
# include <TESsaNova_PP_Loop_Timer_19Aug2013.c>
# include <TESsaNova_Citi_Wall_19Aug2013.c>
# include <TESsaNova_AnalogSensors_19Aug2013.c>
# include <TESsaNova_Switches_19Aug2013.c>
# include <TESsaNova_Citi_Wall_Content_19Aug2013.c>
# include <TESsaNova_Musica_19Aug2013.c>
// # include <TESsaNova_FlashWrite_19Aug2013.c>
# include <TESsaNova_DAC_Drive19Aug2013.c>

/*
void StoreParameters(void)
{
    HB_on();
// Parameters are less than the previous example. Take Care!
    Memorize (Duration, AC_Current, DC_Current, 
               Frequency);
    HB_off();
    // Report "Parameters Memorized."
    Parameters_Saved ();
    wait(300);		                  // Wait for 500 mseconds more

}
*/

void Check_Battery(void)
{
  // Battery Check Code***********************************************************        
          // Read Battery
          // Maximum voltage expected is 18V. Normally, 9 V battery will
          // be used and expected returned number is 900 cV.
          // If Vs<750cV, stop and report the error -Battery Exhaust
          // If Vs<800 & Vs>750cV, just warn the user and continue
          // If Vs<750cV, warn the user and stop there.
          Supply_Voltage();
          // in centivolts cV
          if ((Vs_Read_value<800)&(Vs_Read_value>750))
          {
          // set Error
          // Report to CitiWall
          Citi_Wall_Battery();
          Play_it_Sam ("MahnaMahna:d=16,o=6,b=125:c#,c.,b5,8a#.5,8f.,4g#,a#,g.,4d#,8p,c#,c.,b5,8a#.5,8f.,g#.,8a#.,"); 
          wait(2000);
	  }
          // Insert Test Report here
          // Battery condition and test results
          // If Error_Beacon did not light up during test, it is OK.
          // If Battery Error, it is reasonable, otherwise another error with the device.
          Supply_Voltage();
          if (Vs_Read_value<750)
          {
          // set Error
          // Report to CitiWall
          Citi_Wall_Battery();
Play_it_Sam ("GoodBad:d=4,o=5,b=56:32p,32a#,32d#6,32a#,32d#6,8a#.,16f#.,16g#.,d#,32a#,32d#6,32a#,32d#6,8a#.,16f#.,16g#.,c#6,32a#,"); 
          wait(2000);
          while (1)
          {
          }
          }
// End of Battery Check Code****************************************************     
}

// Initialization
void Init(void) {	            // Init HW&SW
//      BCSCTL3 |= LFXT1S_0;        // 32 kHz Crystal
        Board_Setup();
        Clock_Setting ();
        Clock_Set ();
//      Test_Info_Memory();
        Loop_Timer();
        __bis_SR_register( __SR_GIE );
        wait(100);		              // Wait for 500 mseconds more
        tDCS_Parameters();
        // Make sure that the Stimulator turns off.
        // set OD high
        XTR_Out_Disable = 0x01;
//      Make sure that the Stimulator turns off.
//      Mode5 sets output to zero.
        DAC_Write(5, 1, 0, 0);    
	Citi_Wall_0 ();		      // Welcome Screen
	wait(100);		      // Wait for 500 mseconds more
//        Changed = 0;                // If it is 1, then store parameters to Flash.
//        have to think how to store parameters
//        Remember_Parameters();      // Recall whatever required
        
        // Initially connect to the ShowroomDummy
        // set BRLY = 0;
        Board_Relay = 0;
        // Turn_Off LEDs
        Board_LED = 0;
        HeartBeat_LED = 0;
        Error_Beacon_off ();
        // p5.7 OnBoard activity Monitor
        p5_7 = 0;
        Check_Battery();         
}

void RunTestLoop(int Test_Amplitude, int Test_Duration)
{
          // Turn off heartbeat and turn on LED
          Stimulation_On = 1;
          // Route the current from Subject Body Model to the Output
          // set BRLY = 1;
          Board_Relay = 1;   
          // During relay turn on, there is a voltage peak at the output.
          // I will use the following delay, to isolate it.
          // Exact 10ms delay.
          // OK. When I connected a second scope probe it disappeared.
          // Seems to be a very low energy pulse.
          wait(10);
          // Turn ON the Stimulator .
          // set OD low
          XTR_Out_Disable = 0x00;
          // Set Stimulation Marker (ZP & ZAP) output ON
          // This signal is output of IC601 pin6 with 1k series resistor.
          // IC601 is x4049, so inverted output. Could be used to monitor
          // electrically or an LED might be connected on the panel.	    
          Stimulation_Marker = 0x00;
          // During Process Loops, it is 0.
          // This flag is used to message the run status to emergency check.
          Looping = 0;	
          // void Stimulation_Output (int AC_Amplitude, int DC_Amplitude, int Frequency, int Duration)
          // Frequency should not be zero for sampling purposes! Bad style, keep it for now.
          Test_Stimulation_Output (0, Test_Amplitude, 50, Test_Duration);
          // Make sure that the Stimulator turns off.
          // set OD high
          XTR_Out_Disable = 0x01;
          // Set Stimulation Marker (ZP & ZAP) output OFF
          Stimulation_Marker = 0x01;   
          // Route the current to theSubject Body Model  
          // set BRLY = 1;
          Board_Relay = 1;      
          // During Process Loops, it is 0.
          // This flag is used to message the run status to emergency check.
          Looping = 1;	
          // Turn on heartbeat and turn off LED
          Stimulation_On = 0;
}

// Detailed testing to be done over the human model
// Testing will reveal correct operation by comparing set current 
// and measured current. It will be repeated for a range of current 
// levels. That will also give information about battery status under load.
void Test_It_Detail(void)
{
  // Test_Step determines the current steps in uA
  int Test_Step = 500;
  // Test_Duration is taken to be 1sec each
  int Test_Duration = 1;
  for (Test_Amplitude = Test_Step ; Test_Amplitude <= 2000; Test_Amplitude = Test_Amplitude + Test_Step)
  {
          Citi_Wall_Testing();
          RunTestLoop(Test_Amplitude, Test_Duration);
          Check_Battery();
  }
  Play_it_Sam ("MissionImp:d=16,o=6,b=95:32d,32d#,32d,32d#,32d,32d#,32d");
  Play_it_Sam ("MissionImp:d=16,o=6,b=95:32d,32d#,32d,32d#,32d,32d#,32d");
  wait(500);
}

void RunStimulationLoop(void)
{
          // Turn off heartbeat and turn on LED
          Stimulation_On = 1;
          // Route the current from Subject Body Model to the Output
          // set BRLY = 1;
          Board_Relay = 1;   
          // During relay turn on, there is a voltage peak at the output.
          // I will use the following delay, to isolate it.
          // Exact 10ms delay.
          // OK. When I connected a second scope probe it disappeared.
          // Seems to be a very low energy pulse.
          wait(10);
          // Turn ON the Stimulator .
          // set OD low
          XTR_Out_Disable = 0x00;
          // Set Stimulation Marker (ZP & ZAP) output ON
          // This signal is output of IC601 pin6 with 1k series resistor.
          // IC601 is x4049, so inverted output. Could be used to monitor
          // electrically or an LED might be connected on the panel.	    
          Stimulation_Marker = 0x00;
          // During Process Loops, it is 0.
          // This flag is used to message the run status to emergency check.
          Looping = 0;		
          // void Stimulation_Output (int AC_Amplitude, int DC_Amplitude, int Frequency, int Duration)
          Stimulation_Output ((int)Amplitude_Set_value, (int)DC_Offset_Set_value, (int)Frequency_Set_value, Stimulation_Duration);
          // Make sure that the Stimulator turns off.
          // set OD high
          XTR_Out_Disable = 0x01;
          // Set Stimulation Marker (ZP & ZAP) output OFF
          Stimulation_Marker = 0x01;   
          // Route the current from Output to theSubject Body Model  
          // set BRLY = 0;
          Board_Relay = 0;      
          // During Process Loops, it is 0.
          // This flag is used to message the run status to emergency check.
          Looping = 1;	
          // Turn on heartbeat and turn off LED
          Stimulation_On = 0;
}

// Process Loop
int main (void)
    {
    // Might add default DCO here, in case an interrupt needs to be served. 
    // Not a necessity now.
    __disable_interrupt();
//  Play_it_Sam ("MissionImp:d=16,o=6,b=95:32d,32d#,32d,32d#,32d,32d#,32d,32d#,32d,32d,32d#,32e,32f,32f#,32g,g,8p,g,8p,a#,p,c7,p,g,8p,g,8p,f,p,f#,p,g,8p,g,8p,a#,p,c7,p,g,8p,g,8p,f,p,f#,p,a#,g,2d,32p,a#,g,2c#,32p,a#,g,2c,a#5,8c,2p,32p,a#5,g5,2f#,32p,a#5,g5,2f,32p,a#5,g5,2e,d#,8d");
    Play_it_Sam ("MissionImp:d=16,o=6,b=95:32d,32d#,32d,32d#,32d,32d#,32d,32d#,32d,32d,32d#,32e,32f,32f#");
    WDTCTL = WDTPW + WDTHOLD;         // Stop WDT
    Init ();			      // Init HW&SW
    // Check Process Key. If button is pressed during startup phase
    // Then run the test routine.
    Process_Key ();
    if (Process == 1)
    {
      Test_It_Detail();
    }
while (1){			      // Main Loop
  	// Read Panel
        Panel_Read ();
        // Update CitiWall and HB
	Citi_Wall_Params ();
	wait(10);
	if (Process == 1)             // Make it 0 for Continuous Run to test!
        {               
//  Following for storage of parameters
//  if (Changed == 1){
//  Changed = 0;
//  StoreParameters();
          Citi_Wall_Params ();
          wait(100);		      // Wait for 100 mseconds more
          Play_it_Sam ("MissionImp:d=16,o=6,b=95:32d,32d#,32d,32d#,32d,32d#,32d");
          wait(300);
          Check_Battery();
          Citi_Wall_Loops();
          wait(10);
          RunStimulationLoop();       
//        Graceful ending to the Session
//        Report Stimulation Data
//        Report Errors  
          Play_it_Sam ("Indiana:d=4,o=5,b=250:e,8p,8f,8g,8p,1c6,8p.,d,8p#");
          wait(500);
          Check_Battery();
          wait(100);
          Citi_Wall_Params ();
  }
//        Remember_Parameters();      // Recall whatever required
//        Beep(100, 2);               // Beep is no Good.
        }
	}

/*
// Timer B0 interrupt service routine
#pragma vector=TIMERB0_VECTOR
__interrupt void Timer_B0 (void)
{
      HB ^= 0x01;               // To monitor interrupt cycle
      bit.TickISR = 1;
}
*/

