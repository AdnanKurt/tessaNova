
/*This file has been prepared for Doxygen automatic documentation generation.*/
/*! \file *********************************************************************
 *
* TESsaNova: tDCS TransCranial DC Brain Stimulator
* Developed for research studies at MAKELab
*
* Switch Readings File
*
* Adnan Kurt
* Teknofil
* 12Sep. 2013
* Zekeriyakoy, Istanbul
* - File:               TESsaNova_Switches_12Sep2013.c
* - Compiler:           IAR EWBMSP430 5.40
* - Supported devices:  MSP430F149
* - Circuit:            TESsaNova_19Nov2011_F.sch
*
*  \author    AdKu            \n
*             Adnan Kurt      \n
*             Teknofil        \n
*             12Sep. 2013     \n
*             Zekeriyakoy, Istanbul
*
*
*******************************************************************************/

int More;
int Less;
int length;
int Changed;
int Stimulation_Duration_select = 0;
int Stimulation_Duration_Set = 0;
unsigned int Stimulation_Duration = 10;
void Citi_Wall_Params (void);

/*
unsigned int Duration = 2;             // default 16-bit value to write to segment A 
unsigned int Stimulation_Duration = 10;// default 16-bit value to write to segment A  
unsigned int Period = 20;              // default 16-bit value to write to segment A  
unsigned int OnTime = 25;              // default 16-bit value to write to segment A   
unsigned int OffTime = 75;             // default 16-bit value to write to segment A 
unsigned int Compliance_Voltage = 10;  // kept for consistency. 
int Stimulation_Mode = 1;              // kept for consistency.
*/

/*
// Accelerated Switch Read
// Add error statement (More & Less) == 1 then error. Later
void Read_Stimulation_Duration (void){
More = Increment;
Less = Decrement;
  if ((More | Less) == 1){
  int LoopConstant = 200;               // number of delay constants
  int LoopAcceleration = 1;             // minimum loop constant = 1
  wait (1);
  while (More | Less == 1){
  	if ((More == 1) & (Less == 0)){
	Stimulation_Duration += 10 ;    // tested +=LoopAcceleration, too fast.
	}
	if ((More == 0) & (Less == 1)){
	Stimulation_Duration -= 10 ;    // 10 sec steps
	}
	Citi_Wall_Params();                 // This should be parameter update
	wait (LoopConstant);	            // Acceleration
	LoopConstant = 200 / LoopAcceleration;	
        LoopAcceleration = LoopAcceleration + 1;
More = Increment;    // Resample switches
Less = Decrement;    // Resample switches
        if (Stimulation_Duration > 3600)
        {
          Stimulation_Duration = 10;
        }
        if (Stimulation_Duration < 11)
        {
          Stimulation_Duration = 10;
        }
	if (LoopAcceleration > 190)
        {
	  LoopAcceleration = 200;
        }
  }
    Changed = 1;
  }
  }
*/

void EmergencyKey (void)
{
  
// Normally, Stimulation_trigger/ EmergencyKey input is at 0V.
// To adapt to the Emergency Key check in PP_Loop Timer, I inverted the signal.
// Emergency = !Stimulation_trigger;
// When Button is pressed, Emergency is 1
   Emergency = Stimulation_trigger;
}

// Read ProcessKey
// If PushButton is pressed, check noise, and then, Wait until release
// to start processing.
// Normally, Stimulation_trigger input is at 0V.
void Process_Key (void) {	    // Check Process button	
  if (Stimulation_trigger == 1){	
    length = 100;
    Beep(100, 1);
    wait (20);
    if (Stimulation_trigger == 1){
      while (Stimulation_trigger == 1) {
      HB_off ();
      }
      Process = 1 ;
    }
  } else{
      Process = 0 ;
    }
}

// stimulation_duration (Stimulation Duration in seconds) selection using 
// E24 Renard Numbers in S:
// Instead, I will use Octal series:
/*
unsigned int  a = 100;
unsigned int  b = 120;
unsigned int  c = 150;
unsigned int  d = 180;
unsigned int  e = 220;
unsigned int  f = 270;
unsigned int  g = 330;
unsigned int  h = 390;
*/

// Stimulation Session Duration spans 10sec-3600sec. Fair enough.
unsigned int  a = 10;
unsigned int  b = 60;
unsigned int  c = 120;
unsigned int  d = 300;
unsigned int  e = 600;
unsigned int  f = 900;
unsigned int  g = 1200;
unsigned int  h = 1800;
unsigned int  m = 3600;

void Stimulation_Duration_Calculate(int Stimulation_Duration_select)
{
    switch (Stimulation_Duration_select){
    case 0 : Stimulation_Duration_Set = a;
    break;
    case 1 : Stimulation_Duration_Set = b;
    break;
    case 2 : Stimulation_Duration_Set = c;
    break;
    case 3 : Stimulation_Duration_Set = d;
    break;
    case 4 : Stimulation_Duration_Set = e;
    break;
    case 5 : Stimulation_Duration_Set = f;
    break;
    case 6 : Stimulation_Duration_Set = g;
    break;
    case 7 : Stimulation_Duration_Set = h;
    break;
    case 8 : Stimulation_Duration_Set = m;
    break;    
    default: Stimulation_Duration_Set = a;
    break;
    }
    Stimulation_Duration = (unsigned int)Stimulation_Duration_Set;
}

// Read Pulsewidth using inc/ dec switches
void Read_Stimulation_Duration(void){
    if (Stimulation_Duration_select == 9){
      Stimulation_Duration_select = 0;
    }
    if (Increment == 1) 
    {
      wait (1);
      if (Increment == 1)
      {
          // void Beep (int length, int freq)
          // Acknowledge the key progress
          Beep (40, 2);        
        while (Increment == 1) 
        {
        }
        Stimulation_Duration_select ++;
      }
    }
    if (Decrement == 1) 
    {
      wait (1);
      if (Decrement == 1)
      {
          // void Beep (int length, int freq)
          // Acknowledge the key progress
          Beep (40, 3);
        while (Decrement == 1) 
        {
        }
        Stimulation_Duration_select --;
      }
    }
    Stimulation_Duration_Calculate(Stimulation_Duration_select);
  }
 
void Panel_Read (void){
//  Amplitude_Set_Read();
  DC_Offset_Set_Read();
//  Frequency_Set_Read();
//  Sense_Current();
//  Supply_Voltage();
//  Board_Tempera_Sensor();
  Read_Stimulation_Duration();
  Process_Key ();
}