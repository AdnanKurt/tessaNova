
/*This file has been prepared for Doxygen automatic documentation generation.*/
/*! \file *********************************************************************
 *
* TESsaNova: tDCS TransCranial DC Brain Stimulator
* Developed for research studies at MAKELab
*
* Analog Sensor Conversions File
*
* Adnan Kurt
* Teknofil
* 19Aug. 2013
* Zekeriyakoy, Istanbul
* - File:               TESsaNova_Board_Definition_File_19Aug2013.c
* - Compiler:           IAR EWBMSP430 5.40
* - Supported devices:  MSP430F149
* - Circuit:            TESsaNova_19Nov2011_F.sch
*
*  \author    AdKu            \n
*             Adnan Kurt      \n
*             Teknofil        \n
*             19Aug. 2013     \n
*             Zekeriyakoy, Istanbul
*
# define  Current_Sample_Read   P6IN_bit.P0           
// 0x01 // 0000 0001b p6  // Output Current Sample
# define  Amplitude_Set_Pot     P6IN_bit.P1
// 0x02 // 0000 0010b p6  // Amplitude Set Pot
# define  DC_Offset_Set_Pot     P6IN_bit.P2
// 0x04 // 0000 0100b p6  // DC Offset Set Pot
# define  Freq_Set_Pot          P6IN_bit.P3
// 0x08 // 0000 1000b p6  // Frequency Set Pot
# define  Battery_Monitor       P6IN_bit.P5
// 0x20 // 0010 0000b p6  // Battery Monitor
*
* Pot values need to be scaled for comparision and initial value settings!
*
*******************************************************************************/

unsigned int  Amplitude_Set = 0;
double  Amplitude_Set_value = 0;
unsigned int  DC_Offset_Set = 0;
double  DC_Offset_Set_value = 0;
unsigned int  Frequency_Set = 50;
double  Frequency_Set_value = 50;

// Amplitude_Set_Pot Read Routine
void Amplitude_Set_Read (void) {
  ADC12CTL1 = 0;
  ADC12CTL0 = 0;
  Amplitude_Set = 0;
  Amplitude_Set_value = 0;
  int (loopy)= 101;                     // Number of samples to average.
  ADC12MCTL0 = INCH_1 | SREF_0 ;
  ADC12CTL1 = CSTARTADD_0 | SHS_0 | ADC12DIV_2 | ADC12SSEL_2 | CONSEQ_0 | SHP;  
  ADC12CTL0 = ADC12ON | REFON | SHT0_8 | REF2_5V;
  ADC12CTL0_bit.ENC = 1;
              Delay(_10us);
              Delayx100us(2);           //2ms
              while (loopy > 1) 
              {
                loopy --;
                ADC12CTL0_bit.ADC12SC = 1;
                while (ADC12CTL1_bit.ADC12BUSY == 1){
                                                    }	
                // Amplitude_Set_Read
                // No need to scale with voltage reference.
                // Amplitude_Set_Read = (ADCread/4096)*2500mV max.
                // Scale Amplitude_Set_value = (Amplitude_Set_value/4096)*2000 uA
                Amplitude_Set = ADC12MEM0;
                if (NoiseTest1 > 0)
                {
                if (fabs(NoiseTest1-Amplitude_Set)> 2000)
                {
                    Amplitude_Set = (int)NoiseTest1;
                    Amplitude_Set_value = Amplitude_Set_value + Amplitude_Set;
                }
                  else {Amplitude_Set_value = Amplitude_Set_value + Amplitude_Set;
                }
                }
                  else {Amplitude_Set_value = Amplitude_Set_value + Amplitude_Set;
                }
                }
  ADC12CTL0_bit.ENC = 0;
  Amplitude_Set_value = Amplitude_Set_value / 100;
  NoiseTest1 = (int)Amplitude_Set_value;
  Amplitude_Set_value = (Amplitude_Set_value/4096)*2000;
  if (Amplitude_Set_value >= MaxAmplitude){
    Amplitude_Set_value = MaxAmplitude;
  }
  if (Amplitude_Set_value < 1.0){
    Amplitude_Set_value = 0.0;
  }
  ADC12CTL0 = 0;                           
  ADC12CTL1 = 0;
}

// DC_Offset_Set_Pot Read Routine
void DC_Offset_Set_Read (void){
  ADC12CTL1 = 0;
  ADC12CTL0 = 0;
  DC_Offset_Set = 0;
  DC_Offset_Set_value = 0;
  int (loopy)= 101;                     // Number of samples to average.
  ADC12MCTL0 = INCH_2 | SREF_0 ;
  ADC12CTL1 = CSTARTADD_0 | SHS_0 | ADC12DIV_2 | ADC12SSEL_2 | CONSEQ_0 | SHP;  
  ADC12CTL0 = ADC12ON | REFON | SHT0_8 | REF2_5V;
  ADC12CTL0_bit.ENC = 1;
              Delay(_10us);
              Delayx100us(2);           //2ms
              while (loopy > 1) 
              {
                loopy --;
                ADC12CTL0_bit.ADC12SC = 1;
                while (ADC12CTL1_bit.ADC12BUSY == 1){
                                                    }	
                // DC_Offset_Set_Read
                // No need to scale with voltage reference.
                // DC_Offset_Set_Read = (ADCread/4096)*2500mV max.
                // Scale DC_Offset_Set_value = (DC_Offset_Set_value/4096)*2000 uA
                DC_Offset_Set = ADC12MEM0;
                if (NoiseTest2 > 0)
                {
                if (fabs(NoiseTest2-DC_Offset_Set)> 2000)
                {
                    DC_Offset_Set = (int)NoiseTest2;
                    DC_Offset_Set_value = DC_Offset_Set_value + DC_Offset_Set;
                }
                  else {DC_Offset_Set_value = DC_Offset_Set_value + DC_Offset_Set;
                }
                }
                  else {DC_Offset_Set_value = DC_Offset_Set_value + DC_Offset_Set;
                }
                }
  ADC12CTL0_bit.ENC = 0;
  DC_Offset_Set_value = DC_Offset_Set_value / 100;
  NoiseTest2 = (int)DC_Offset_Set_value;
  // On MediPol device, maximum DC level was 1800 uA, so I've used 2300 factor
  DC_Offset_Set_value = (DC_Offset_Set_value/4096)*2300;
  if (DC_Offset_Set_value >= MaxDCOffset){
    DC_Offset_Set_value = MaxDCOffset;
  }
  if (DC_Offset_Set_value < 1.0){
    DC_Offset_Set_value = 0.0;
  }
  ADC12CTL0 = 0;                           
  ADC12CTL1 = 0;
}

// Frequency_Set_Pot Read Routine
void Frequency_Set_Read (void){
  ADC12CTL1 = 0;
  ADC12CTL0 = 0;
  Frequency_Set = 0;
  Frequency_Set_value = 0;
  int (loopy)= 101;                     // Number of samples to average.
  ADC12MCTL0 = INCH_3 | SREF_0 ;
  ADC12CTL1 = CSTARTADD_0 | SHS_0 | ADC12DIV_2 | ADC12SSEL_2 | CONSEQ_0 | SHP;  
  ADC12CTL0 = ADC12ON | REFON | SHT0_8 | REF2_5V;
  ADC12CTL0_bit.ENC = 1;
              Delay(_10us);
              Delayx100us(2);           //2ms
              while (loopy > 1) 
              {
                loopy --;
                ADC12CTL0_bit.ADC12SC = 1;
                while (ADC12CTL1_bit.ADC12BUSY == 1){
                                                    }	
                // Frequency_Set_read
                // No need to scale with voltage reference.
                // Frequency_Set_read = (ADCread/4096)*2500mV max.
                // Scale Frequency_Set_value = (Frequency_Set_value/4096)*200 Hz
                Frequency_Set = ADC12MEM0;
                if (NoiseTest3 > 0)
                {
                // Check value (2000) caused freezing. 
                // Increasing solved the problem.
                if (fabs(NoiseTest3-DC_Offset_Set)> 4000)
                {
                    Frequency_Set = (int)NoiseTest3;
                    Frequency_Set_value = Frequency_Set_value + Frequency_Set;
                }
                  else {Frequency_Set_value = Frequency_Set_value + Frequency_Set;
                }
                }
                  else {Frequency_Set_value = Frequency_Set_value + Frequency_Set;
                }
                }
  ADC12CTL0_bit.ENC = 0;
  Frequency_Set_value = Frequency_Set_value / 100;
  NoiseTest3 = (int)Frequency_Set_value;
  // Maximum frequency that we can get is 80Hz with 4*subsampling at 4MHz SMCLK
  // So, dHz unit will be used, and down to 0.1Hz can be achieved at low end.
  Frequency_Set_value = (Frequency_Set_value/4096)*800;
  if (Frequency_Set_value >= MaxFrequency){
    Frequency_Set_value = MaxFrequency;
  }
  if (Frequency_Set_value < 1.0){
    Frequency_Set_value = 1.0;
  }
  ADC12CTL0 = 0;                           
  ADC12CTL1 = 0;
}

// Sense_i Read Routine
// Output current sampling. However, this routine might better be embedded into 
// Interrupt service request
void Sense_Current (void){
  ADC12CTL1 = 0;
  ADC12CTL0 = 0;
  Sense_i_read = 0;
  int (loopy)= 100;                    // Number of samples to average.
  ADC12MCTL0 = INCH_0 | SREF_1 ;       // Use 2.5V reference
  ADC12CTL1 = CSTARTADD_0 | SHS_0 | ADC12DIV_2 | ADC12SSEL_2 | CONSEQ_0 | SHP;  
  ADC12CTL0 = ADC12ON | REFON | SHT0_8 | REF2_5V;
  ADC12CTL0_bit.ENC = 1;
              Delay(_10us);
              Delayx100us(2);           //2ms
              while (loopy > 1) 
              {
                loopy --;
                ADC12CTL0_bit.ADC12SC = 1;
                while (ADC12CTL1_bit.ADC12BUSY == 1){
                                                    }	
                // Sense_i_read
                // No need to scale with voltage reference.
                // Sense_i_read = (ADCread/4096)*2500mV max.
                // CUSA floats at 375mV baseline. That is as expected. 
                // There is 190mV reference offset at INA118 output. 
                // So, that is reflected to the OPA336 output as 
                // (1+24/33)*190=378mV.
                Sense_i_read = ADC12MEM0;
                if (NoiseTest4 > 0)
                {
                if (fabs(NoiseTest4-Sense_i_read)> 2000)
                {
                    Sense_i_read = (int)NoiseTest4;
                    Sense_i_value = Sense_i_value + Sense_i_read;
                }
                  else {Sense_i_value = Sense_i_value + Sense_i_read;
                }
                }
                  else {Sense_i_value = Sense_i_value + Sense_i_read;
                }
                }
  ADC12CTL0_bit.ENC = 0;
  Sense_i_value = Sense_i_value / 100;
  NoiseTest4 = (int)Sense_i_value;
  // So, that is reflected to the OPA336 output as 
  // (1+24/33)*190=378mV.
  // Sense_i_value = ((Sense_i_value*2500)/4096-378)/285; mA
  // in uA 
  Sense_i_value = ((Sense_i_value*(305.0/500.0)-378.0)*(1000.0/285.0));
  if (Sense_i_value >= MaxCurrent){
    Sense_i_value = MaxCurrent;
  }
  if (Sense_i_value < 1.0){
    Sense_i_value = 0.0;
  }
  ADC12CTL0 = 0;                           
  ADC12CTL1 = 0;
}

// Supply Voltage Read Routine
void Supply_Voltage (void){
  ADC12CTL1 = 0;
  ADC12CTL0 = 0;
  Vs_Read_Read = 0;
  int (loopy)= 101;                     // Number of samples to average.
  ADC12MCTL0 = INCH_5 | SREF_1 ;        // 2.5V reference used
  ADC12CTL1 = CSTARTADD_0 | SHS_0 | ADC12DIV_2 | ADC12SSEL_2 | CONSEQ_0 | SHP;  
  ADC12CTL0 = ADC12ON | REFON | SHT0_8 | REF2_5V;
  ADC12CTL0_bit.ENC = 1;
              Delay(_10us);
              Delayx100us(2);           //2ms
              while (loopy > 1) 
              {
                loopy --;
                ADC12CTL0_bit.ADC12SC = 1;
                while (ADC12CTL1_bit.ADC12BUSY == 1){
                                                    }	
                // Vs_Read
                // No need to scale with voltage reference.
                // Vs_Read = (ADCread/4096)*2500mV max.
                Vs_Read_Read = ADC12MEM0;
                if (NoiseTest5 > 0)
                {
                if (fabs(NoiseTest5-Vs_Read_Read)> 2000)
                {
                    Vs_Read_Read = NoiseTest5;
                    Vs_Read_value = Vs_Read_value + Vs_Read_Read;
                }
                  else {Vs_Read_value = Vs_Read_value + Vs_Read_Read;
                }
                }
                  else {Vs_Read_value = Vs_Read_value + Vs_Read_Read;
                }
                }
  ADC12CTL0_bit.ENC = 0;
  Vs_Read_value = Vs_Read_value / 100;
  NoiseTest5 = (int)Vs_Read_value;
  // Maximum voltage that we can read is 18V 
  // So, cV unit will be used
  // Vs_Read_value = (Vs_Read_value/4096)*2500*(18/2500);
  // In place of (18/2500), use the exact transfer function
  // Vs_Read_value = (Vs_Read_value/4096)*2500*(18/1500);
  // Vs_Read_value = (Vs_Read_value/4096.0)*9*(25.0/15.0);
  // in centivolts cV
  Vs_Read_value = (Vs_Read_value*15.0/4096.0)*100;
  if (Vs_Read_value >= MaxVoltage){
    Vs_Read_value = MaxVoltage;
  }
  if (Vs_Read_value < 1.0){
    Vs_Read_value = 0.0;
  }
  ADC12CTL0 = 0;                           
  ADC12CTL1 = 0;
}

// Board_Tempera Read Routine
// Board temperature monitor -just in case.
void Board_Tempera_Sensor (void) {
int long IntDegC;
  ADC12CTL0 = SHT0_8 + REFON + ADC12ON;
  ADC12CTL1 = SHP;                          // enable sample timer
  ADC12MCTL0 = SREF_1 + INCH_10;
  ADC12CTL0 |= ENC;
  ADC12CTL0 |= ADC12SC;                   // Sampling and conversion start
//  oC = ((x/4096)*1500mV)-986mV)*1/3.55mV = x*423/4096 - 278
//  IntDegC = (ADC12MEM0 - 2692)* 423/4096
  while (ADC12CTL1_bit.ADC12BUSY == 1){
  }	
  Board_Temperature = ADC12MEM0;          // Move results, IFG is cleared
  IntDegC = (int)((Board_Temperature - 2692) * 423);
  IntDegC = IntDegC / 4096;
  Board_Temperature = IntDegC;
  ADC12CTL0 = 0;                           
  ADC12CTL1 = 0;
  }

/* 
Circular Buffer Example
//------------------------------------------------------------------------------
// The Timer_A CCR0 ISR is called on each TACCR0 capture event to obtain
// the time stamp of the input signal transition. An 8-tap moving average
// filter is used to minimize measurement error.
//------------------------------------------------------------------------------
#pragma vector = TIMERA0_VECTOR
__interrupt void TimerA0_ISR(void)
{
  SpeedMemSum -= SpeedMem[pSpeedMem];           // Remove oldest value
  SpeedMem[pSpeedMem] = (unsigned int)(TACCR0 - LastTACCR);  // Replace with current
  SpeedMemSum += SpeedMem[pSpeedMem++];         // Update running sum
  CurrentSpeed = SpeedMemSum >> 3;              // Calc speed by div 8
  pSpeedMem &= 0x07;                            // Adjust circular pointer

  LastTACCR = TACCR0;
  TACCR1 = LastTACCR + MIN_SPEED;               // Set timeout for minimum speed
}                                               // to be read out
*/
